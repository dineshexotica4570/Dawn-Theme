import React from 'react';

const Dashboard = () => {
    return (
        <div>
            <h2 className="mt-3">Welcome to your Dashboard</h2>
            {/* Additional Dashboard content can go here */}
        </div>
    );
};

export default Dashboard;
