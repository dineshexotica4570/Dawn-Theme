import React, { useState, useEffect } from 'react';
import Chart from 'chart.js/auto';
import '../App.css';
import base_url from '../config';
const Dashboard = () => {
    // const [notifications, setNotifications] = useState([]);
    const [showNotifications, setShowNotifications] = useState(false);
    const [orderCounts, setOrderCounts] = useState({ completed: 0, processing: 0, cancelled: 0 });

    // useEffect(() => {
    //     const ws = new WebSocket('ws://localhost:5000');

    //     ws.onopen = () => {
    //         console.log('WebSocket connected');
    //     };

    //     ws.onmessage = (event) => {
    //         const notification = JSON.parse(event.data);
    //         setNotifications(prevNotifications => [...prevNotifications, notification]);
    //     };

    //     ws.onclose = () => {
    //         console.log('WebSocket disconnected');
    //     };

    //     return () => {
    //         ws.close();
    //     };
    // }, []);

    useEffect(() => {
        const userdata = JSON.parse(localStorage.getItem('user'));
        const userRole = userdata?.user_role;
        setShowNotifications(userRole === 'Admin');

        // Fetch orders data from API
        fetch(`${base_url}/api/orders`)
            .then(response => response.json())
            .then(data => {
                // Calculate counts and percentages
                let completedCount = 0, processingCount = 0, cancelledCount = 0;
                const totalOrders = data.length;

                data.forEach(order => {
                    switch (order.status) {
                        case 'completed':
                            completedCount++;
                            break;
                        case 'processing':
                            processingCount++;
                            break;
                        case 'cancelled':
                            cancelledCount++;
                            break;
                        default:
                            break;
                    }
                });

                // Calculate percentages
                const completedPercentage = (completedCount / totalOrders) * 100;
                const processingPercentage = (processingCount / totalOrders) * 100;
                const cancelledPercentage = (cancelledCount / totalOrders) * 100;

                // Update state with order counts
                setOrderCounts({ completed: completedCount, processing: processingCount, cancelled: cancelledCount });

                // Create chart using Chart.js
                const ctx = document.getElementById('orderChart').getContext('2d');

                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: ['Completed', 'Processing', 'Cancelled'],
                        datasets: [{
                            label: 'Order Status',
                            data: [completedCount, processingCount, cancelledCount],
                            backgroundColor: [
                                'rgba(75, 192, 192, 0.2)', // Green
                                'rgba(255, 206, 86, 0.2)', // Yellow
                                'rgba(255, 99, 132, 0.2)', // Red
                            ],
                            borderColor: [
                                'rgba(75, 192, 192, 1)',
                                'rgba(255, 206, 86, 1)',
                                'rgba(255, 99, 132, 1)',
                            ],
                            borderWidth: 1
                        }]
                    },
                    options: {
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });
    }, []);

    return (
        <div>
              <h2 className="mt-3">Welcome to Dashboard</h2>
            {showNotifications && (
                <div>
                    {/* <h3>Notifications</h3>
                    <ul className="notification-list">
                        {notifications.map((notification, index) => (
                            <li key={index} className="notification-item">{notification.message}</li>
                        ))}
                    </ul> */}
                  
            <div className="chart-container">
              
                <p>Total Orders: {orderCounts.completed + orderCounts.processing + orderCounts.cancelled}</p>
              
                <canvas id="orderChart" width="400" height="200"></canvas>
            </div>
                </div>
                
            )}

           
        </div>
    );
};

export default Dashboard;
