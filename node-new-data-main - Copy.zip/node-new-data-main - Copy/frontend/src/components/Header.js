// Header.js

import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { FaShoppingCart } from 'react-icons/fa';


const Header = () => {
    const [cartCount, setCartCount] = useState(0);

    useEffect(() => {
      
        const updateCartCount = () => {

            const cartState = JSON.parse(localStorage.getItem('cartState'));
            if(cartState){
                console.log(cartState);

                const totalCount = cartState.items.reduce((total, item) => total + item.quantity, 0);
            
                setCartCount(totalCount);
            }
           
           
        };
        updateCartCount(); 
    }, []);
    return (
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark py-20 fixed-top">
            <div className="container">
                <Link className="navbar-brand" to="/">Ecoomerce</Link>
                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse  justify-content-end" id="navbarNav" >
                    <ul className="navbar-nav mr-auto">
                        <li className="nav-item">
                            <Link className="nav-link text-white " to="/">Home</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link text-white" to="/about">About</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link text-white" to="/posts">Blogs</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link text-white" to="/shop">Shop</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link text-white" to="/login">Login</Link>
                        </li>
                        <li className="nav-item">
                        <Link className="nav-link text-white" to="/cart">
                            <FaShoppingCart />({cartCount})
                        </Link>
                    </li>
                        <li className="nav-item">
                            <Link className="nav-link text-white" to="/checkout">Checkout</Link>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    );
};

export default Header;
