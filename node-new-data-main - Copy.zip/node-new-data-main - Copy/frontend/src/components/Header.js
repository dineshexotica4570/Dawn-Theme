import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { FaShoppingCart } from 'react-icons/fa';
import { Navbar, Nav } from 'react-bootstrap';

const Header = () => {
    const [cartCount, setCartCount] = useState(0);
    const [expanded, setExpanded] = useState(false);

    useEffect(() => {
        const updateCartCount = () => {
            const cartState = JSON.parse(localStorage.getItem('cartState'));
            if (cartState) {
                console.log(cartState);
                const totalCount = cartState.items.reduce((total, item) => total + item.quantity, 0);
                setCartCount(totalCount);
            }
        };
        updateCartCount();
    }, []);

    return (
        <Navbar expanded={expanded} expand="lg" bg="dark" variant="dark" fixed="top">
            <div className="container">
                <Link className="navbar-brand" to="/">Ecommerce</Link>
                <Navbar.Toggle 
                    aria-controls="navbarNav"
                    onClick={() => setExpanded(expanded ? false : true)} 
                />
                <Navbar.Collapse id="navbarNav" className="justify-content-end">
                    <Nav className="mr-auto">
                        <Nav.Link as={Link} to="/" onClick={() => setExpanded(false)}>Home</Nav.Link>
                        <Nav.Link as={Link} to="/about" onClick={() => setExpanded(false)}>About</Nav.Link>
                        <Nav.Link as={Link} to="/posts" onClick={() => setExpanded(false)}>Blogs</Nav.Link>
                        <Nav.Link as={Link} to="/shop" onClick={() => setExpanded(false)}>Shop</Nav.Link>
                        <Nav.Link as={Link} to="/login" onClick={() => setExpanded(false)}>Login</Nav.Link>
                        <Nav.Link as={Link} to="/cart" onClick={() => setExpanded(false)}>
                            <FaShoppingCart /> ({cartCount})
                        </Nav.Link>
                        <Nav.Link as={Link} to="/checkout" onClick={() => setExpanded(false)}>Checkout</Nav.Link>
                    </Nav>
                </Navbar.Collapse>
            </div>
        </Navbar>
    );
};

export default Header;
