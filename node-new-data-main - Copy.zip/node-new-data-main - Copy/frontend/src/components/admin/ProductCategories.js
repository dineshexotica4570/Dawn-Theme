import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Table, Button, Modal, Form, Pagination, Row, Col } from 'react-bootstrap';
import base_url from '../../config';

const ProductCategories = () => {
    const [categories, setCategories] = useState([]);
    const [showAddModal, setShowAddModal] = useState(false);
    const [showEditModal, setShowEditModal] = useState(false);
    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [newCategory, setNewCategory] = useState({ name: '', description: '', image: null });
    const [editCategory, setEditCategory] = useState({ _id: '', name: '', description: '', currentImage: '', image: null });
    const [deleteCategoryId, setDeleteCategoryId] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [searchQuery, setSearchQuery] = useState('');
    const categoriesPerPage = 8;

    useEffect(() => {
        const fetchCategories = async () => {
            const response = await axios.get(`${base_url}/api/product_cat`);
            setCategories(response.data);
        };
        fetchCategories();
    }, []);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setNewCategory({ ...newCategory, [name]: value });
    };

    const handleEditInputChange = (e) => {
        const { name, value } = e.target;
        setEditCategory({ ...editCategory, [name]: value });
    };

    const handleFileChange = (e) => {
        setNewCategory({ ...newCategory, image: e.target.files[0] });
    };

    const handleEditFileChange = (e) => {
        setEditCategory({ ...editCategory, image: e.target.files[0] });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log(newCategory);
        const formData = new FormData();
        formData.append('name', newCategory.name);
        formData.append('description', newCategory.description);
        formData.append('image', newCategory.image);
        
        await axios.post(`${base_url}/api/product_cat`, formData);
        handleAddClose();
        const response = await axios.get(`${base_url}/api/product_cat`);
        setCategories(response.data);
        resetForm();
    };

    const handleEditSubmit = async (e) => {
        e.preventDefault();
        const formData = new FormData();
        formData.append('name', editCategory.name);
        formData.append('description', editCategory.description);
        if (editCategory.image) {
            formData.append('image', editCategory.image);
        }

        await axios.put(`${base_url}/api/product_cat/${editCategory._id}`, formData);
        handleEditClose();
        const response = await axios.get(`${base_url}/api/product_cat`);
        setCategories(response.data);
    };

    const handleDelete = async () => {
        try {
            await axios.delete(`${base_url}/api/product_cat/${deleteCategoryId}`);
            handleDeleteClose();
            const response = await axios.get(`${base_url}/api/product_cat`);
            setCategories(response.data);
        } catch (error) {
            console.error('Error deleting the category', error);
        }
    };

    const handleSearchInputChange = (e) => {
        setSearchQuery(e.target.value);
    };

    const filteredCategories = categories.filter((category) =>
        (category.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        category.description?.toLowerCase().includes(searchQuery.toLowerCase()))
    );
    

    const indexOfLastCategory = currentPage * categoriesPerPage;
    const indexOfFirstCategory = indexOfLastCategory - categoriesPerPage;
    const currentCategories = filteredCategories.slice(indexOfFirstCategory, indexOfLastCategory);

    const paginate = (pageNumber) => setCurrentPage(pageNumber);

    const handleAddClose = () => setShowAddModal(false);
    const handleAddShow = () => setShowAddModal(true);
    const handleEditClose = () => setShowEditModal(false);
    const handleEditShow = (category) => {
        setEditCategory({ ...category, currentImage: `${base_url}/api/${category.image}`, image: null });
        setShowEditModal(true);
    };
    const handleDeleteClose = () => setShowDeleteModal(false);
    const handleDeleteShow = (categoryId) => {
        setDeleteCategoryId(categoryId);
        setShowDeleteModal(true);
    };

    const resetForm = () => {
        setNewCategory({ name: '', description: '', image: null });
    };

    return (
        <div>
            <h2>Categories Page</h2>

            <Row className="mb-3">
                <Col>
                    <Button variant="primary" onClick={handleAddShow}>
                        Add New
                    </Button>
                </Col>
                <Col>
                    <Form.Group controlId="formSearch">
                        <Form.Control
                            type="text"
                            placeholder="Search Categories by name or description"
                            value={searchQuery}
                            onChange={handleSearchInputChange}
                        />
                    </Form.Group>
                </Col>
            </Row>
            <Table striped bordered hover className="mt-3">
                <thead>
                    <tr>
                        <th>Name</th>
                  
                        <th>Description</th>
                        <th>Image</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {currentCategories.map((category) => (
                        <tr key={category._id}>
                            <td>{category.name}</td>
                           
                            <td>{category.description}</td>
                            <td>
                                {category.image && (
                                    <img
                                        src={`${base_url}/api/${category.image}`}
                                        alt={category.name}
                                        style={{ width: '100px' }}
                                    />
                                )}
                            </td>
                            <td>
                                <div className="actions">
                                    <Button variant="warning" className="mr-2" onClick={() => handleEditShow(category)}>
                                        Edit
                                    </Button>
                                    <Button variant="danger" onClick={() => handleDeleteShow(category._id)}>
                                        Delete
                                    </Button>
                                </div>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </Table>

            <Pagination className="mt-3">
                <Pagination.Prev onClick={() => paginate(currentPage - 1)} disabled={currentPage === 1} />
                {Array.from({ length: Math.ceil(filteredCategories.length / categoriesPerPage) }, (_, index) => (
                    <Pagination.Item key={index + 1} onClick={() => paginate(index + 1)} active={index + 1 === currentPage}>
                        {index + 1}
                    </Pagination.Item>
                ))}
                <Pagination.Next
                    onClick={() => paginate(currentPage + 1)}
                    disabled={currentPage === Math.ceil(filteredCategories.length / categoriesPerPage)}
                />
            </Pagination>

            <Modal show={showAddModal} onHide={handleAddClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Add New Category</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={handleSubmit}>
                        <Form.Group controlId="formName">
                            <Form.Label>Name</Form.Label>
                            <Form.Control type="text" name="name" value={newCategory.name} onChange={handleInputChange} required />
                        </Form.Group>
                        
                        <Form.Group controlId="formDescription">
                            <Form.Label>Description</Form.Label>
                            <Form.Control as="textarea" rows={3} name="description" value={newCategory.description} onChange={handleInputChange} required />
                        </Form.Group>
                        <Form.Group controlId="formImage">
                            <Form.Label>Image</Form.Label>
                            <Form.Control type="file" name="image" onChange={handleFileChange} required />
                        </Form.Group>
                        <Button variant="primary" type="submit" className="mt-3">
                            Save Category
                        </Button>
                    </Form>
                </Modal.Body>
            </Modal>

            <Modal show={showEditModal} onHide={handleEditClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Edit Category</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={handleEditSubmit}>
                        <Form.Group controlId="editFormName">
                            <Form.Label>Name</Form.Label>
                            <Form.Control type="text" name="name" value={editCategory.name} onChange={handleEditInputChange} required />
                        </Form.Group>
                       
                        <Form.Group controlId="editFormDescription">
                            <Form.Label>Description</Form.Label>
                            <Form.Control as="textarea" rows={3} name="description" value={editCategory.description} onChange={handleEditInputChange} required />
                        </Form.Group>
                        <Form.Group controlId="editFormCurrentImage">
                            <Form.Label>Current Image</Form.Label>
                            <br />
                            {editCategory.currentImage && (
                                <img src={editCategory.currentImage} alt="Current" style={{ width: '100px' }} />
                            )}
                        </Form.Group>
                        <Form.Group controlId="editFormImage">
                            <Form.Label>New Image</Form.Label>
                            <Form.Control type="file" name="image" onChange={handleEditFileChange} />
                        </Form.Group>
                        <Button variant="primary" type="submit" className="mt-3">
                            Update Category
                        </Button>
                    </Form>
                </Modal.Body>
            </Modal>

            <Modal show={showDeleteModal} onHide={handleDeleteClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Delete Confirmation</Modal.Title>
                </Modal.Header>
                <Modal.Body>Are you sure you want to delete this category?</Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleDeleteClose}>
                        Cancel
                    </Button>
                    <Button variant="danger" onClick={handleDelete}>
                        Delete
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
};

export default ProductCategories;
