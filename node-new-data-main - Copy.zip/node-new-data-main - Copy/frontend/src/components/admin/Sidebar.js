import React, { useState, useEffect } from 'react';
import { Nav, Button } from 'react-bootstrap';
import { useNavigate, Link } from 'react-router-dom';
import base_url from '../../config';
const Sidebar = () => {
    const navigate = useNavigate();
    const [userRole, setUserRole] = useState('');

    useEffect(() => {
        const user = JSON.parse(localStorage.getItem('user'));
        if (user.userId) {
            fetch(`${base_url}/api/users/${user.userId}`)
                .then(response => response.json())
                .then(data => {
                    setUserRole(data.role); // Assuming role is returned from API
                })
                .catch(error => console.error('Error fetching user data:', error));
        }
    }, []);
    const handleLogout = () => {
        localStorage.removeItem('user');
        navigate('/login');
    };

    return (
        <div className="bg-light sidebar-sticky vh-100 position-relative">
            <div className='dashborder-col '>
                <h3 className="text-center mt-3">Dashboard</h3>
                <h6 className=" mt-1 text-center text-decoration-none mb-2'"><Link to="/" className='text-decoration-none mb-2'>View Site</Link></h6>
            </div>
            <Nav className="flex-column mt-4">
                <Link to="/dashboard" className='text-decoration-none mb-2 bg-secondary py-2 ps-2 text-white'>Dashboard</Link>
                {userRole === 'Admin' ? (
                    <>
                        <Link to="/dashboard/posts" className='text-decoration-none mb-2 bg-secondary py-2 ps-2 text-white'>Posts</Link>
                        <Link to="/dashboard/products" className='text-decoration-none mb-2 bg-secondary py-2 ps-2 text-white'>Products</Link>
                        <Link to="/dashboard/orders" className='text-decoration-none mb-2 bg-secondary py-2 ps-2 text-white'>Orders</Link>
                        <Link to="/dashboard/users" className='text-decoration-none mb-2 bg-secondary py-2 ps-2 text-white'>Users</Link>
                        <Link to="/dashboard/profile" className='text-decoration-none mb-2 bg-secondary py-2 ps-2 text-white'>Profile</Link>
                    </>
                ) : (
                    <>
                        <Link to="/dashboard/profile" className='text-decoration-none mb-2 bg-secondary py-2 ps-2 text-white'>Profile</Link>
                        <Link to="/dashboard/orders" className='text-decoration-none mb-2 bg-secondary py-2 ps-2 text-white'>Orders</Link>
                        {/* Add more non-admin links here */}
                    </>
                )}
            </Nav>
            <Button variant="danger" className="mb-4 position-absolute bottom-0 left-3" onClick={handleLogout}>Logout</Button>
        </div>
    );
};

export default Sidebar;
