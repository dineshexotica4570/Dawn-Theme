import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Table, Button, Modal, Form, Pagination, Row, Col } from 'react-bootstrap';
import base_url from '../../config';
const Users = () => {
    const [users, setUsers] = useState([]);
    const [showAddModal, setShowAddModal] = useState(false);
    const [showEditModal, setShowEditModal] = useState(false);
    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [newUser, setNewUser] = useState({email: '', role: 'Subscriber', password: '' });
    const [editUser, setEditUser] = useState({ _id: '', email: '', role: '', currentRole: '', password: '' });
    const [deleteUserId, setDeleteUserId] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [searchQuery, setSearchQuery] = useState('');
    const usersPerPage = 8;

    const handleAddClose = () => setShowAddModal(false);
    const handleAddShow = () => setShowAddModal(true);
    const handleEditClose = () => setShowEditModal(false);
    const handleEditShow = (user) => {
        setEditUser({ ...user, currentRole: user.role });
        setShowEditModal(true);
    };
    const handleDeleteClose = () => setShowDeleteModal(false);
    const handleDeleteShow = (userId) => {
        setDeleteUserId(userId);
        setShowDeleteModal(true);
    };

    useEffect(() => {
        const fetchUsers = async () => {
            const response = await axios.get(`${base_url}/api/users`);
            setUsers(response.data);
        };
        fetchUsers();
    }, []);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setNewUser({ ...newUser, [name]: value });
    };
    
    const handleEditInputChange = (e) => {
        const { name, value } = e.target;
        setEditUser({ ...editUser, [name]: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post(`${base_url}/api/users`, newUser);
            handleAddClose();
            const response = await axios.get(`${base_url}/api/users`);
            setUsers(response.data);
            resetForm();
        } catch (error) {
            console.error('Error adding user:', error);
        }
    };

    const handleEditSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.put(`${base_url}/api/userss/${editUser._id}`, editUser);
            handleEditClose();
            const response = await axios.get(`${base_url}/api/users`);
            setUsers(response.data);
        } catch (error) {
            console.error('Error updating user:', error);
        }
    };

    const handleDelete = async () => {
        try {
            await axios.delete(`${base_url}/api/users/${deleteUserId}`);
            handleDeleteClose();
            const response = await axios.get(`${base_url}/api/users`);
            setUsers(response.data);
        } catch (error) {
            console.error('Error deleting user:', error);
        }
    };

    const handleSearchInputChange = (e) => {
        setSearchQuery(e.target.value);
    };

    const filteredUsers = users.filter((user) =>
       
        user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.role.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const indexOfLastUser = currentPage * usersPerPage;
    const indexOfFirstUser = indexOfLastUser - usersPerPage;
    const currentUsers = filteredUsers.slice(indexOfFirstUser, indexOfLastUser);

    const paginate = (pageNumber) => setCurrentPage(pageNumber);

    const resetForm = () => {
        setNewUser({ email: '', role: '', password: '' });
    };

    return (
        <div>
            <h2>Users Page</h2>
            
            <Row className="mb-3">
                <Col>
                    <Button variant="primary" onClick={handleAddShow}>
                        Add New User
                    </Button>
                </Col>
                <Col>
                    <Form.Group controlId="formSearch">
                        <Form.Control
                            type="text"
                            placeholder="Search Users by name, email, or role"
                            value={searchQuery}
                            onChange={handleSearchInputChange}
                        />
                    </Form.Group>
                </Col>
            </Row>
            <Table striped bordered hover className="mt-3">
                <thead>
                    <tr>
                       
                        <th>Email</th>
                        <th>Role</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {currentUsers.map((user) => (
                        <tr key={user._id}>
                           
                            <td>{user.email}</td>
                            <td>{user.role}</td>
                            <td>
                                <div className="actions">
                                    <Button variant="warning" className="mr-2" onClick={() => handleEditShow(user)}>Edit</Button>
                                    <Button variant="danger" onClick={() => handleDeleteShow(user._id)}>Delete</Button>
                                </div>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </Table>

            <Pagination className="mt-3">
                <Pagination.Prev onClick={() => paginate(currentPage - 1)} disabled={currentPage === 1} />
                {Array.from({ length: Math.ceil(filteredUsers.length / usersPerPage) }, (_, index) => (
                    <Pagination.Item key={index + 1} onClick={() => paginate(index + 1)} active={index + 1 === currentPage}>
                        {index + 1}
                    </Pagination.Item>
                ))}
                <Pagination.Next onClick={() => paginate(currentPage + 1)} disabled={currentPage === Math.ceil(filteredUsers.length / usersPerPage)} />
            </Pagination>

            <Modal show={showAddModal} onHide={handleAddClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Add New User</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={handleSubmit}>
                     
                        <Form.Group controlId="formEmail">
                            <Form.Label>Email</Form.Label>
                            <Form.Control
                                type="email"
                                name="email"
                                value={newUser.email}
                                onChange={handleInputChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group controlId="formRole">
                            <Form.Label>Role</Form.Label>
                            <Form.Control
                                as="select"
                                name="role"
                                value={newUser.role}
                                onChange={handleInputChange}
                                required
                            >
                                <option value="Admin">Admin</option>
                                <option value="Subscriber">Subscriber</option>
                                <option value="Customer">Customer</option>
                            </Form.Control>
                        </Form.Group>
                        <Form.Group controlId="formPassword">
                            <Form.Label>Password</Form.Label>
                            <Form.Control
                                type="password"
                                name="password"
                                value={newUser.password}
                                onChange={handleInputChange}
                                required
                            />
                        </Form.Group>
                        <Button variant="primary" type="submit" className="mt-3">
                            Save User
                        </Button>
                    </Form>
                </Modal.Body>
            </Modal>

            <Modal show={showEditModal} onHide={handleEditClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Edit User</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={handleEditSubmit}>
                       
                        <Form.Group controlId="editFormEmail">
                            <Form.Label>Email</Form.Label>
                            <Form.Control
                                type="email"
                                name="email"
                                value={editUser.email}
                                onChange={handleEditInputChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group controlId="editFormRole">
                            <Form.Label>Role</Form.Label>
                            <Form.Control
                                as="select"
                                name="role"
                                value={editUser.role}
                                onChange={handleEditInputChange}
                                required
                            >
                                <option value="Admin">Admin</option>
                                <option value="Subscriber">Subscriber</option>
                                <option value="Customer">Customer</option>
                            </Form.Control>
                        </Form.Group>
                        <Form.Group controlId="editFormPassword">
                            <Form.Label>New Password</Form.Label>
                            <Form.Control
                                type="password"
                                name="password"
                                value={editUser.password}
                                onChange={handleEditInputChange}
                            />
                        </Form.Group>
                        <Button variant="primary" type="submit" className="mt-3">
                            Update User
                        </Button>
                    </Form>
                </Modal.Body>
            </Modal>

            <Modal show={showDeleteModal} onHide={handleDeleteClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Delete Confirmation</Modal.Title>
                </Modal.Header>
                <Modal.Body>Are you sure you want to delete this user?</Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleDeleteClose}>
                        Cancel
                    </Button>
                    <Button variant="danger" onClick={handleDelete}>
                        Delete
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
};

export default Users;
