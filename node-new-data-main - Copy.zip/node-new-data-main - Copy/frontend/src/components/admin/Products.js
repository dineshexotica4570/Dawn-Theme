import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchProducts, addProduct, updateProduct, deleteProduct } from '../../redux/products/productsSlice';
import { Table, Button, Modal, Form, Pagination, Row, Col } from 'react-bootstrap';
import base_url from '../../config';
const Products = () => {
    const dispatch = useDispatch();
    const products = useSelector((state) => state.products.products);
    const [showAddModal, setShowAddModal] = useState(false);
    const [showEditModal, setShowEditModal] = useState(false);
    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [newProduct, setNewProduct] = useState({ name: '', description: '', quantity: 0, price: '', image: null });
    const [editProduct, setEditProduct] = useState({ _id: '', name: '', description: '', quantity: 0, price: '', currentImage: '', image: null });
    const [deleteProductId, setDeleteProductId] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [searchQuery, setSearchQuery] = useState('');
    const productsPerPage = 8;

    const handleAddClose = () => setShowAddModal(false);
    const handleAddShow = () => setShowAddModal(true);
    const handleEditClose = () => setShowEditModal(false);
    const handleEditShow = (product) => {
        setEditProduct({ ...product, currentImage: `${base_url}/api/${product.image}`, image: null });
        setShowEditModal(true);
    };
    const handleDeleteClose = () => setShowDeleteModal(false);
    const handleDeleteShow = (productId) => {
        setDeleteProductId(productId);
        setShowDeleteModal(true);
    };

    useEffect(() => {
        dispatch(fetchProducts());
    }, [dispatch]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setNewProduct({ ...newProduct, [name]: value });
    };

    const handleEditInputChange = (e) => {
        const { name, value } = e.target;
        setEditProduct({ ...editProduct, [name]: value });
    };

    const handleFileChange = (e) => {
        setNewProduct({ ...newProduct, image: e.target.files[0] });
    };

    const handleEditFileChange = (e) => {
        setEditProduct({ ...editProduct, image: e.target.files[0] });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        dispatch(addProduct(newProduct));
        handleAddClose();
        resetForm();
    };

    const resetForm = () => {
        setNewProduct({ name: '', description: '', quantity: 0, price: '', image: null });
    };

    const handleEditSubmit = (e) => {
        e.preventDefault();
        dispatch(updateProduct(editProduct));
        handleEditClose();
    };

    const handleDelete = () => {
        dispatch(deleteProduct(deleteProductId));
        handleDeleteClose();
    };

    const handleSearchInputChange = (e) => {
        setSearchQuery(e.target.value);
    };

    const filteredProducts = products.filter((product) =>
        product.name.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const indexOfLastProduct = currentPage * productsPerPage;
    const indexOfFirstProduct = indexOfLastProduct - productsPerPage;
    const currentProducts = filteredProducts.slice(indexOfFirstProduct, indexOfLastProduct);

    return (
        <div>
            <Row className="mb-3">
                <Col>
                    <Button variant="primary" onClick={handleAddShow}>
                        Add Product
                    </Button>
                </Col>
                <Col>
                    <Form.Control
                        type="text"
                        placeholder="Search by name"
                        value={searchQuery}
                        onChange={handleSearchInputChange}
                    />
                </Col>
            </Row>

            <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Image</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {currentProducts.map((product, index) => (
                        <tr key={product._id}>
                            <td>{index + 1 + indexOfFirstProduct}</td>
                            <td>{product.name}</td>
                            <td>{product.description}</td>
                            <td>{product.quantity}</td>
                            <td>{product.price}</td>
                            <td>
                                <img src={`${base_url}/api/${product.image}`} alt={product.name} style={{ width: '50px' }} />
                            </td>
                            <td>
                                <Button variant="warning" onClick={() => handleEditShow(product)}>
                                    Edit
                                </Button>{' '}
                                <Button variant="danger" onClick={() => handleDeleteShow(product._id)}>
                                    Delete
                                </Button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </Table>

            <Pagination>
                {[...Array(Math.ceil(filteredProducts.length / productsPerPage)).keys()].map((number) => (
                    <Pagination.Item key={number + 1} active={number + 1 === currentPage} onClick={() => setCurrentPage(number + 1)}>
                        {number + 1}
                    </Pagination.Item>
                ))}
            </Pagination>

            {/* Add Product Modal */}
            <Modal show={showAddModal} onHide={handleAddClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Add New Product</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={handleSubmit}>
                        <Form.Group controlId="formName">
                            <Form.Label>Name</Form.Label>
                            <Form.Control
                                type="text"
                                name="name"
                                value={newProduct.name}
                                onChange={handleInputChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group controlId="formDescription">
                            <Form.Label>Description</Form.Label>
                            <Form.Control
                                as="textarea"
                                rows={3}
                                name="description"
                                value={newProduct.description}
                                onChange={handleInputChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group controlId="formQuantity">
                            <Form.Label>Quantity</Form.Label>
                            <Form.Control
                                type="number"
                                name="quantity"
                                value={newProduct.quantity}
                                onChange={handleInputChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group controlId="formPrice">
                            <Form.Label>Price</Form.Label>
                            <Form.Control
                                type="text"
                                name="price"
                                value={newProduct.price}
                                onChange={handleInputChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group controlId="formImage">
                            <Form.Label>Image</Form.Label>
                            <Form.Control
                                type="file"
                                name="image"
                                onChange={handleFileChange}
                                required
                            />
                        </Form.Group>
                        <Button variant="primary" type="submit" className="mt-3">
                            Save Product
                        </Button>
                    </Form>
                </Modal.Body>
            </Modal>

            {/* Edit Product Modal */}
            <Modal show={showEditModal} onHide={handleEditClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Edit Product</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={handleEditSubmit}>
                        <Form.Group controlId="editFormName">
                            <Form.Label>Name</Form.Label>
                            <Form.Control
                                type="text"
                                name="name"
                                value={editProduct.name}
                                onChange={handleEditInputChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group controlId="editFormDescription">
                            <Form.Label>Description</Form.Label>
                            <Form.Control
                                as="textarea"
                                rows={3}
                                name="description"
                                value={editProduct.description}
                                onChange={handleEditInputChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group controlId="editFormQuantity">
                            <Form.Label>Quantity</Form.Label>
                            <Form.Control
                                type="number"
                                name="quantity"
                                value={editProduct.quantity}
                                onChange={handleEditInputChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group controlId="editFormPrice">
                            <Form.Label>Price</Form.Label>
                            <Form.Control
                                type="text"
                                name="price"
                                value={editProduct.price}
                                onChange={handleEditInputChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group controlId="editFormCurrentImage">
                            <Form.Label>Current Image</Form.Label>
                            <br />
                            {editProduct.currentImage && (
                                <img
                                    src={editProduct.currentImage}
                                    alt="Current"
                                    style={{ width: '100px' }}
                                />
                            )}
                        </Form.Group>
                        <Form.Group controlId="editFormImage">
                            <Form.Label>New Image</Form.Label>
                            <Form.Control
                                type="file"
                                name="image"
                                onChange={handleEditFileChange}
                            />
                        </Form.Group>
                        <Button variant="primary" type="submit" className="mt-3">
                            Update Product
                        </Button>
                    </Form>
                </Modal.Body>
            </Modal>

            {/* Delete Confirmation Modal */}
            <Modal show={showDeleteModal} onHide={handleDeleteClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Delete Confirmation</Modal.Title>
                </Modal.Header>
                <Modal.Body>Are you sure you want to delete this product?</Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleDeleteClose}>
                        Cancel
                    </Button>
                    <Button variant="danger" onClick={handleDelete}>
                        Delete
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
};

export default Products;
