import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Modal, Button } from 'react-bootstrap';
import base_url from '../../config';

const OrdersListing = () => {
    const [orders, setOrders] = useState([]);
    const [showViewModal, setShowViewModal] = useState(false);
    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [selectedOrder, setSelectedOrder] = useState(null);

    useEffect(() => {
        fetchOrders();
    }, []);

    const fetchOrders = async () => {
        try {
            const response = await axios.get(`${base_url}/api/orders`);
            const ordersWithData = await Promise.all(response.data.map(async (order) => {
                // Fetch product names
                const productNames = await Promise.all(order.items.map(async (item) => {
                    try {
                        const productResponse = await axios.get(`${base_url}/api/products/${item.productId}`);
                        return productResponse.data.name;
                    } catch (error) {
                        console.error('Error fetching product name:', error);
                        return 'Not Available'; // Handle fallback value
                    }
                }));

                // Fetch user email
                try {
                    const userResponse = await axios.get(`${base_url}/api/users/${order.userId}`);
                    const userEmail = userResponse.data.email;

                    return {
                        ...order,
                        productNames,
                        userEmail
                    };
                } catch (error) {
                    console.error('Error fetching user email:', error);
                    return {
                        ...order,
                        productNames,
                        userEmail: 'Not Available' // Handle fallback value
                    };
                }
            }));

            const userdata = JSON.parse(localStorage.getItem('user'));
            const user_role = userdata.user_role;
            if (user_role === 'Admin') {
                setOrders(ordersWithData);
            } else if (user_role === 'Customer') {
                const filteredOrders = ordersWithData.filter(order => order.userId === userdata.userId);
                setOrders(filteredOrders);
            }
        } catch (error) {
            console.error('Error fetching orders:', error);
        }
    };

    const handleStatusChange = async (orderId, newStatus) => {
        try {
            const order = orders.find(order => order._id === orderId);
            const response = await axios.put(`${base_url}/api/orders/${orderId}`, { status: newStatus, items: order.items });
            const updatedOrder = response.data;
            setOrders(prevOrders =>
                prevOrders.map(order => (order._id === updatedOrder._id ? updatedOrder : order))
            );
        } catch (error) {
            console.error('Error updating order status:', error);
        }
    };

    const handleDeleteOrder = async () => {
        try {
            const response = await axios.delete(`${base_url}/api/orders/${selectedOrder._id}`);
            if (response.status === 200) {
                setOrders(prevOrders => prevOrders.filter(order => order._id !== selectedOrder._id));
                setShowDeleteModal(false);
            }
        } catch (error) {
            console.error('Error deleting order:', error);
        }
    };

    const confirmDeleteOrder = (order) => {
        setSelectedOrder(order);
        setShowDeleteModal(true);
    };

    const viewShippingAddress = (order) => {
        console.log(order);
        setSelectedOrder(order);
        setShowViewModal(true);
    };

    return (
        <div>
            <h2>Orders</h2>
            <table className="table">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Product Name(s)</th>
                        <th>User Email</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>More Information</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {orders.map(order => (
                        <tr key={order._id}>
                            <td>{order._id}</td>
                            <td>{order.productNames ? order.productNames.join(', ') : 'Not Available'}</td>
                            <td>{order.userEmail ? order.userEmail : 'Not Available'}</td>
                            <td>{order.items ? order.items.map(item => item.quantity).join(', ') : 'Not Available'}</td>
                            <td>${order.total}</td>
                            <td>
                                <button className="btn btn-primary" onClick={() => viewShippingAddress(order)}>
                                    View More
                                </button>
                            </td>
                            <td>
                                <select
                                    value={order.status}
                                    onChange={e => handleStatusChange(order._id, e.target.value)}
                                >
                                    <option value="processing">Processing</option>
                                    <option value="cancelled">Cancelled</option>
                                    <option value="completed">Completed</option>
                                </select>
                            </td>
                            <td>
                                <button className="btn btn-danger" onClick={() => confirmDeleteOrder(order)}>
                                    Delete
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>

            {/* View Address Modal */}
            <Modal show={showViewModal} onHide={() => setShowViewModal(false)}>
                <Modal.Header closeButton>
                    <Modal.Title>Shipping Address</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <p><strong>Order ID:</strong> {selectedOrder ? selectedOrder._id : ''}</p>
                    <p><strong>Customer Name:</strong>{selectedOrder && selectedOrder.shippingAddress && (<p>{selectedOrder.shippingAddress.fullname}</p>)}</p>
                    <p><strong>Email :</strong> {selectedOrder ? selectedOrder.userEmail : ''}</p>
                    <p><strong>Product Name:</strong> {selectedOrder ? selectedOrder.productNames : ''}</p>
                  
                    {selectedOrder && selectedOrder.items && selectedOrder.items.map((item, index) => (
                        <div key={index}>
                            <p><strong>Product Price:</strong> ${item.price}</p>
                            <p><strong>Product Quantity:</strong> {item.quantity}</p>
                        </div>
                    ))}
                    <p><strong>Shipping Address:</strong></p>
                    {selectedOrder && selectedOrder.shippingAddress && (
                        <address>
                            <p>{selectedOrder.shippingAddress.addressLine1}</p>
                            <p>{selectedOrder.shippingAddress.addressLine2}</p>
                          
                            <p>{selectedOrder.shippingAddress.city}, {selectedOrder.shippingAddress.state}, {selectedOrder.shippingAddress.country}, {selectedOrder.shippingAddress.zip}</p>
                        </address>
                    )}
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={() => setShowViewModal(false)}>
                        Close
                    </Button>
                </Modal.Footer>
            </Modal>

            {/* Delete Confirmation Modal */}
            <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)}>
                <Modal.Header closeButton>
                    <Modal.Title>Confirm Delete</Modal.Title>
                </Modal.Header>
                <Modal.Body>Are you sure you want to delete this order?</Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
                        Cancel
                    </Button>
                    <Button variant="danger" onClick={handleDeleteOrder}>
                        Delete
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
};

export default OrdersListing;
