import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Modal, Button } from 'react-bootstrap';
import base_url from '../../config';
const OrdersListing = () => {
    const [orders, setOrders] = useState([]);
    const [showactions, setshowactions] = useState(false);
    const [showModal, setShowModal] = useState(false);
    const [orderIdToDelete, setOrderIdToDelete] = useState(null);
    

    useEffect(() => {
        
        fetchOrders();
    }, []);

    const fetchOrders = async () => {
        try {
            const response = await axios.get(`${base_url}/api/orders`);
            const ordersWithData = await Promise.all(response.data.map(async (order) => {
                // Fetch product names
                const productNames = await Promise.all(order.items.map(async (item) => {
                    try {
                        const productResponse = await axios.get(`${base_url}/api/products/${item.productId}`);
                        return productResponse.data.name;
                    } catch (error) {
                        console.error('Error fetching product name:', error);
                        return 'Not Available'; // Handle fallback value
                    }
                }));

                // Fetch user email
                try {
                    const userResponse = await axios.get(`${base_url}/api/users/${order.userId}`);
                    
                    const userEmail = userResponse.data.email;

                    return {
                        ...order,
                        productNames,
                        userEmail
                    };
                } catch (error) {
                    console.error('Error fetching user email:', error);
                    return {
                        ...order,
                        productNames,
                        userEmail: 'Not Available' // Handle fallback value
                    };
                }
            }));

           
            const userdata = JSON.parse(localStorage.getItem('user'));
            const user_role = userdata.user_role;
            if (user_role === 'Admin') {
                console.log('Admin');
                setshowactions('Admin');
                setOrders(ordersWithData);
            } else if (user_role === 'Customer') {
               
                const filteredOrders = ordersWithData.filter(order => order.userId === userdata.userId); 
                console.log('Customer');
                setshowactions("Customer");
                setOrders(filteredOrders);
            }
           // setOrders(ordersWithData);
        } catch (error) {
            console.error('Error fetching orders:', error);
        }
    };

    const handleStatusChange = async (orderId, newStatus) => {
        try {
            const order = orders.find(order => order._id === orderId);
            const response = await axios.put(`${base_url}/api/orders/${orderId}`, { status: newStatus, items: order.items });
            const updatedOrder = response.data;
            setOrders(prevOrders =>
                prevOrders.map(order => (order._id === updatedOrder._id ? updatedOrder : order))
            );
        } catch (error) {
            console.error('Error updating order status:', error);
        }
    };

    const handleDeleteOrder = async () => {
        try {
            const response = await axios.delete(`${base_url}/api/orders/${orderIdToDelete}`);
            if (response.status === 200) {
                setOrders(prevOrders => prevOrders.filter(order => order._id !== orderIdToDelete));
                setShowModal(false);
            }
        } catch (error) {
            console.error('Error deleting order:', error);
        }
    };

    const confirmDeleteOrder = (orderId) => {
        setOrderIdToDelete(orderId);
        setShowModal(true);
    };

    return (
        <div>
            <h2>Orders</h2>
            <table className="table">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Product Name(s)</th>
                        <th>User Email</th>
                        <th>Quantity</th>
                        <th>Total</th>

                        {showactions === 'Admin' ? (
                                    <>
                                    <th>Status</th>
                                    <th>Action</th>
                                    </>
                                    ) : (
                                    <>
                                    <th>Action</th>
                                    </>
                                )}
                        
                    </tr>
                </thead>
                <tbody>
                    {orders.map(order => (
                        <tr key={order._id}>
                            <td>{order._id}</td>
                            <td>{order.productNames ? order.productNames.join(', ') : 'Not Available'}</td>
                            <td>{order.userEmail ? order.userEmail : 'Not Available'}</td>
                            <td>{order.items ? order.items.map(item => item.quantity).join(', ') : 'Not Available'}</td>
                            <td>${order.total}</td>


                                {showactions === 'Admin' ? (
                                    <>
                                    <td>
                                    <select
                                        value={order.status}
                                        onChange={e => handleStatusChange(order._id, e.target.value)}
                                    >
                                        <option value="processing">Processing</option>
                                        <option value="cancelled">Cancelled</option>
                                        <option value="completed">Completed</option>
                                    </select>
                                    </td>
                                    <td>
                                    <button className="btn btn-danger" onClick={() => confirmDeleteOrder(order._id)}>
                                        Delete
                                    </button>
                                    </td>
                                    </>
                                    ) : (
                                    <>
                                    <td>
                                    {order.status}
                                    </td>
                                    </>
                                )}
    
                </tr>
                ))}
                </tbody>
            </table>

            <Modal show={showModal} onHide={() => setShowModal(false)}>
                <Modal.Header closeButton>
                    <Modal.Title>Confirm Delete</Modal.Title>
                </Modal.Header>
                <Modal.Body>Are you sure you want to delete this order?</Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={() => setShowModal(false)}>
                        Cancel
                    </Button>
                    <Button variant="danger" onClick={handleDeleteOrder}>
                        Delete
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
};

export default OrdersListing;
