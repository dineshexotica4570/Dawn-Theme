import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import Sidebar from './Sidebar';
import { Outlet } from 'react-router-dom';

const MainLayout = () => {
    return (
        <Container fluid>
            <Row>
                {/* Sidebar */}
                <Col md={3} className="bg-light sidebar">
                    <Sidebar />
                </Col>

                {/* Main Content */}
                <Col md={9} className="ml-sm-auto px-4">
                    <Outlet />
                </Col>
            </Row>
        </Container>
    );
};

export default MainLayout;
