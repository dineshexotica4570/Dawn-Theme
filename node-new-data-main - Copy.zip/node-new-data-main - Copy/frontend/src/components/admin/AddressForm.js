import React, { useState, useEffect } from 'react';
import axios from 'axios';
import base_url from '../../config';

const AddressForm = () => {
  const user = JSON.parse(localStorage.getItem('user'));
  const [addresses, setAddresses] = useState([]);
  const [address, setAddress] = useState({
    fullname: '',
    addressLine1: '',
    addressLine2: '',
    city: '',
    state: '',
    zip: '',
    country: '',
  });
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    const fetchAddresses = async () => {
      try {
        const response = await axios.get(`${base_url}/api/addresses/${user.userId}`);
        setAddresses(response.data);
        if (response.data.length > 0) {
          // If addresses exist, pre-fill the form with the first address found
          const firstAddress = response.data[0];
          setAddress({
            fullname: firstAddress.fullname,
            addressLine1: firstAddress.addressLine1,
            addressLine2: firstAddress.addressLine2 || '',
            city: firstAddress.city,
            state: firstAddress.state,
            zip: firstAddress.zip,
            country: firstAddress.country,
          });
        }
      } catch (error) {
        console.error('Error fetching addresses:', error);
        setError('Failed to fetch addresses. Please try again.');
      }
    };

    fetchAddresses();
  }, [user.userId]); // Fetch addresses whenever user ID changes

  const handleChange = (e) => {
    setAddress({ ...address, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    try {
      const response = await axios.post(`${base_url}/api/addresses`, {
        userId: user.userId,
        address,
      });
      console.log(response.data);
      setSuccess(true);
    } catch (error) {
      console.error('Error saving address:', error);
      setError('Failed to save address. Please try again.');
    }
  };

  return (
    <div className="container mt-4">
      <h2>Add Address</h2>
      <form onSubmit={handleSubmit}>
        {error && <div className="alert alert-danger">{error}</div>}
        {success && <div className="alert alert-success">Address saved successfully.</div>}
        <div className="mb-3">
          <label htmlFor="fullname" className="form-label">Full Name</label>
          <input type="text" className="form-control" id="fullname" name="fullname" value={address.fullname} onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label htmlFor="addressLine1" className="form-label">Address Line 1</label>
          <input type="text" className="form-control" id="addressLine1" name="addressLine1" value={address.addressLine1} onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label htmlFor="addressLine2" className="form-label">Address Line 2</label>
          <input type="text" className="form-control" id="addressLine2" name="addressLine2" value={address.addressLine2} onChange={handleChange} />
        </div>
        <div className="mb-3">
          <label htmlFor="city" className="form-label">City</label>
          <input type="text" className="form-control" id="city" name="city" value={address.city} onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label htmlFor="state" className="form-label">State</label>
          <input type="text" className="form-control" id="state" name="state" value={address.state} onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label htmlFor="zip" className="form-label">ZIP Code</label>
          <input type="text" className="form-control" id="zip" name="zip" value={address.zip} onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label htmlFor="country" className="form-label">Country</label>
          <input type="text" className="form-control" id="country" name="country" value={address.country} onChange={handleChange} required />
        </div>
        
        <button type="submit" className="btn btn-primary">Save Address</button>
      </form>
    </div>
  );
};

export default AddressForm;
