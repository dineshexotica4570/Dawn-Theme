import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

import { clearCart } from '../redux/products/cartSlice';
import Header from './Header';
import Footer from './Footer';

const CheckoutPage = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const items = useSelector((state) => state.cart.items);
    const user = JSON.parse(localStorage.getItem('user')); 


    const total = items.reduce((acc, item) => acc + (item.price * item.quantity), 0);

	const handleCheckout = async () => {
    try {
       
        const order = {
            userId: user.userId, 
            items: items.map(item => ({
                productId: item.id, 
                quantity: item.quantity,
                price: item.price
            })),
            total: total,
            status: 'processing'
        };
        const response = await axios.post('http://localhost:5000/api/orders', order);
        if (response.status === 201) {
            dispatch(clearCart());
            navigate('/place-order', { state: { order: response.data, user: user } });
        }
    } catch (error) {
        console.error('Error placing order:', error);
    }
};


    return (
        <div>
            <Header />
            <div className="container mt-5 pt-4">
                <h2 className='mb-3'>Checkout</h2>
                <ul className="list-group mb-3">
                    {items.map((item) => (
                        <li key={item._id} className="list-group-item d-flex justify-content-between">
                            <div>
                                <h6 className="my-0">{item.name}</h6>
                                <small className="text-muted">Quantity: {item.quantity}</small>
                            </div>
                            <span className="text-muted">${item.price * item.quantity}</span>
                        </li>
                    ))}
                    <li className="list-group-item d-flex justify-content-between">
                        <span>Total (USD)</span>
                        <strong>${total}</strong>
                    </li>
                </ul>
                <button className="btn btn-primary btn-lg btn-block" onClick={handleCheckout}>Place Order</button>
            </div>
            <Footer />
        </div>
    );
};

export default CheckoutPage;
