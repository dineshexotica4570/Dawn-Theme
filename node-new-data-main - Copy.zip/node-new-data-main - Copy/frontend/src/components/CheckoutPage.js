import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

import { clearCart } from '../redux/products/cartSlice';
import Header from './Header';
import Footer from './Footer';
import base_url from '../config';

const CheckoutPage = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const items = useSelector((state) => state.cart.items);
  const user = JSON.parse(localStorage.getItem('user'));

  const total = items.reduce((acc, item) => acc + item.price * item.quantity, 0);

  const [address, setAddress] = useState({
    fullname: '',
    addressLine1: '',
    addressLine2: '',
    city: '',
    state: '',
    zip: '',
    country: '',
  });

  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchAddresses = async () => {
      try {
        const response = await axios.get(`${base_url}/api/addresses/${user.userId}`);
        if (response.data.length > 0) {
          const firstAddress = response.data[0];
          setAddress({
            fullname: firstAddress.fullname,
            addressLine1: firstAddress.addressLine1,
            addressLine2: firstAddress.addressLine2 || '',
            city: firstAddress.city,
            state: firstAddress.state,
            zip: firstAddress.zip,
            country: firstAddress.country,
          });
        }
      } catch (error) {
        console.error('Error fetching addresses:', error);
        setError('Failed to fetch addresses. Please try again.');
      }
    };

    fetchAddresses();
  }, [user.userId]);

  const handleChange = (e) => {
    setAddress({ ...address, [e.target.name]: e.target.value });
  };

  const handleSubmitAddress = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(`${base_url}/api/addresses`, {
        userId: user.userId,
        address,
      });
      console.log('Address saved:', response.data);
      // Optionally, you can set a success message or handle success state
    } catch (error) {
      console.error('Error saving address:', error);
      // Handle error state or display error message
    }
  };

  const handleCheckout = async () => {
    try {
      const order = {
        userId: user.userId,
        items: items.map((item) => ({
          productId: item.id,
          quantity: item.quantity,
          price: item.price,
        })),
        total: total,
        status: 'processing',
        shippingAddress: address, // Include the address in the order object
      };

      const response = await axios.post(`${base_url}/api/orders`, order);
      if (response.status === 201) {
        dispatch(clearCart());
        navigate('/place-order', { state: { order: response.data, user: user } });
      }
    } catch (error) {
      console.error('Error placing order:', error);
    }
  };

  return (
    <div>
      <Header />
      <div className="container mt-5 pt-4">
        <h2 className="mb-3">Checkout</h2>
        <form onSubmit={handleSubmitAddress}>
          <div className="mb-3">
            <label htmlFor="fullname" className="form-label">
              Full Name
            </label>
            <input
              type="text"
              className="form-control"
              id="fullname"
              name="fullname"
              value={address.fullname}
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="addressLine1" className="form-label">
              Address Line 1
            </label>
            <input
              type="text"
              className="form-control"
              id="addressLine1"
              name="addressLine1"
              value={address.addressLine1}
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="addressLine2" className="form-label">
              Address Line 2
            </label>
            <input
              type="text"
              className="form-control"
              id="addressLine2"
              name="addressLine2"
              value={address.addressLine2}
              onChange={handleChange}
            />
          </div>
          <div className="mb-3">
            <label htmlFor="city" className="form-label">
              City
            </label>
            <input
              type="text"
              className="form-control"
              id="city"
              name="city"
              value={address.city}
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="state" className="form-label">
              State
            </label>
            <input
              type="text"
              className="form-control"
              id="state"
              name="state"
              value={address.state}
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="zip" className="form-label">
              ZIP Code
            </label>
            <input
              type="text"
              className="form-control"
              id="zip"
              name="zip"
              value={address.zip}
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="country" className="form-label">
              Country
            </label>
            <input
              type="text"
              className="form-control"
              id="country"
              name="country"
              value={address.country}
              onChange={handleChange}
              required
            />
          </div>
          <button type="submit" className="btn btn-primary">
            Save Address
          </button>
        </form>
        <div className='w-50 ms-auto'>
        <ul className="list-group mb-3">
          {items.map((item) => (
            <li key={item._id} className="list-group-item d-flex justify-content-between">
              <div>
                <h6 className="my-0">{item.name}</h6>
                <small className="text-muted">Quantity: {item.quantity}</small>
              </div>
              <span className="text-muted">${item.price * item.quantity}</span>
            </li>
          ))}
          <li className="list-group-item d-flex justify-content-between">
            <span>Total (USD)</span>
            <strong>${total}</strong>
          </li>
        </ul>
        <button className="btn btn-primary btn-lg btn-block" onClick={handleCheckout}>
          Place Order
        </button>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default CheckoutPage;
