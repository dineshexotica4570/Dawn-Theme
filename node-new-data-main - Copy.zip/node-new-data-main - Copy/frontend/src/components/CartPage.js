// CartPage.js
import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';
import { Table, Button, FormControl, Alert } from 'react-bootstrap';
import { removeItemFromCart, clearCart, updateItemQuantity } from '../redux/products/cartSlice';
import Header from './Header';
import Footer from './Footer';

const CartPage = () => {
    const dispatch = useDispatch();
    const items = useSelector((state) => state.cart.items);
    const [quantities, setQuantities] = useState(
        items.reduce((acc, item) => {
            acc[item._id] = item.quantity;
            return acc;
        }, {})
    );
    const [updateMessage, setUpdateMessage] = useState('');

    useEffect(() => {
        if (updateMessage) {
            const timer = setTimeout(() => setUpdateMessage(''), 3000);
            return () => clearTimeout(timer);
        }
    }, [updateMessage]);

    const handleRemoveFromCart = (id) => {
        dispatch(removeItemFromCart(id));
    };

    const handleClearCart = () => {
        dispatch(clearCart());
    };

    const handleQuantityChange = (id, quantity) => {
        setQuantities({ ...quantities, [id]: quantity });
    };

    const handleUpdateQuantity = (id) => {
        dispatch(updateItemQuantity({ id, quantity: quantities[id] }));
        setUpdateMessage('Cart items updated successfully!');
    };

    const handleUpdateAllQuantities = () => {
        items.forEach((item) => {
            if (quantities[item._id] !== item.quantity) {
                dispatch(updateItemQuantity({ id: item._id, quantity: quantities[item._id] }));
            }
        });
        setUpdateMessage('Cart items updated successfully!');
    };

    return (
        <div>
            <Header />
            <div className="container pt-5">
                <h2 className='mt-4 mb-3'>Cart</h2>
                {updateMessage && <Alert variant="success">{updateMessage}</Alert>}
                <Table striped bordered hover>
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {items.map((item) => (
                            <tr key={item._id}>
                                <td>{item.name}</td>
                                <td>
                                    <FormControl
                                        type="number"
                                        value={quantities[item._id]}
                                        onChange={(e) => handleQuantityChange(item._id, Number(e.target.value))}
                                        min="1"
                                    />
									
                                </td>
                                <td>${item.price * quantities[item._id]}</td>
                                <td>
                                    <Button variant="danger" onClick={() => handleRemoveFromCart(item._id)}>Remove</Button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </Table>
                <Button variant="secondary" onClick={handleClearCart}>Clear Cart</Button>
                <Button variant="primary" onClick={handleUpdateAllQuantities} className="ml-3 mx-3">Update</Button>
                <Link to="/checkout" className="btn btn-primary ml-3">Proceed to Checkout</Link>
            </div>
            <Footer />
        </div>
    );
};

export default CartPage;
