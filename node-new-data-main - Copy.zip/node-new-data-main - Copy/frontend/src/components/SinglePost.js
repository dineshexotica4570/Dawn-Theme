import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, Link } from 'react-router-dom';

import { Container, Row, Col, Card} from 'react-bootstrap';
import Header from './Header';
import Footer from './Footer';

const SinglePost = () => {
    const [post, setPost] = useState(null);
    const { id } = useParams();

    useEffect(() => {
        const fetchPost = async () => {
            try {
                const response = await axios.get(`http://localhost:5000/api/posts/${id}`);
                setPost(response.data);
            } catch (error) {
                console.error('Error fetching post:', error);
            }
        };

        fetchPost();
    }, [id]);

    if (!post) {
        return <div>Loading...</div>;
    }

    return (
        <div>
            <Header />
            <Container className="mt-5 pt-4">
                <Row>
                    <Col md={12}>
                        <nav aria-label="breadcrumb">
                            <ol className="breadcrumb">
                                <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                                <li className="breadcrumb-item"><Link to="/posts">Posts</Link></li>
                                <li className="breadcrumb-item active" aria-current="page">{post.name}</li>
                            </ol>
                        </nav>
                    </Col>
                </Row>
                <Row>
                <Col md={12}>
                        <Card>
                            {post.image && (
                                <Card.Img
                                    variant="top"
                                    src={`http://localhost:5000/api/${post.image}`}
                                    alt={post.name}
                                    style={{ objectFit: 'contain', maxHeight: '400px' }}
                                />
                            )}
                            <Card.Body>
                                <Card.Title>{post.name}</Card.Title>
                                <Card.Text>{post.description}</Card.Text>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
            <Footer />
        </div>
    );
};

export default SinglePost;
