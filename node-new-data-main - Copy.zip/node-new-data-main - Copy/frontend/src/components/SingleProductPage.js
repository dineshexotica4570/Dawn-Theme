import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams, Link } from 'react-router-dom';
import { fetchProductById } from '../redux/products/productsSlice';
import { addItemToCart } from '../redux/products/cartSlice';
import { Card, Button, Form, Alert, Row, Col, Container } from 'react-bootstrap';
import Header from './Header';
import Footer from './Footer';
import base_url from '../config';
const SingleProductPage = () => {
    const { id } = useParams();
    const dispatch = useDispatch();
    const { product, status, error } = useSelector((state) => state.products);
    const [quantity, setQuantity] = useState(1);
    const [availableQuantity, setAvailableQuantity] = useState(0);
    const [message, setMessage] = useState('');
    const [activeTab, setActiveTab] = useState('additional');

    useEffect(() => {
        dispatch(fetchProductById(id));
    }, [dispatch, id]);

    useEffect(() => {
        if (product) {
            setAvailableQuantity(product.quantity);
        }
    }, [product]);

    const handleAddToCart = () => {
        dispatch(addItemToCart({ ...product, quantity, id }));
        setMessage(`Added ${quantity} x ${product.name} to the cart!`);
        setTimeout(() => setMessage(''), 80000); // Clear message after 3 seconds
    };

    const handleQuantityChange = (e) => {
        const value = parseInt(e.target.value, 10);
        if (!isNaN(value) && value >= 1 && value <= availableQuantity) {
            setQuantity(value);
        }
    };

    if (status === 'loading') {
        return <div>Loading...</div>;
    }

    if (status === 'failed') {
        return <div>{error}</div>;
    }
    const handleTabClick = (tabId) => {
        setActiveTab(tabId);
      };
    
    return (
        <div>
            <Header />
            <Container className="mt-5 pt-4">
                {message && (
                    <Alert variant="success" className='d-flex justify-content-between'>
                        {message} <Link to="/cart" className='d-block'>View Cart</Link>
                    </Alert>
                )}
                {product && (
                    <Row>
                        <Col md={6}>
                            <Card.Img variant="top" src={`${base_url}/api/${product.image}`} />
                        </Col>
                        <Col md={6}>
                            <Card.Body>
                                <Card.Title>{product.name}</Card.Title>
                                <Card.Text>{product.description}</Card.Text>
                                <Card.Text><strong>Price: </strong>${product.price}</Card.Text>
                                <Form.Group>
                                    <Form.Label>Quantity</Form.Label>
                                    <Form.Control
                                        type="number"
                                        min="1"
                                        max={availableQuantity}
                                        value={quantity}
                                        onChange={handleQuantityChange}
                                    />
                                </Form.Group>
                                {quantity > availableQuantity ? (
                                    <Button variant="secondary" disabled className='mt-4'>Out of Stock</Button>
                                ) : (
                                    <Button onClick={handleAddToCart} className='mt-4'>Add to Cart</Button>
                                )}
                            </Card.Body>
                        </Col>
                    </Row>
                    
                )}
               <div className="mt-3 mb-3">
      <ul className="nav nav-tabs" id="myTab" role="tablist">
        <li className="nav-item" role="presentation">
          <button
            className={`nav-link ${activeTab === 'additional' ? 'active' : ''}`}
            onClick={() => handleTabClick('additional')}
            type="button"
            role="tab"
            aria-controls="additional"
            aria-selected={activeTab === 'additional'}
          >
            Additional Information
          </button>
        </li>
        <li className="nav-item" role="presentation">
          <button
            className={`nav-link ${activeTab === 'reviews' ? 'active' : ''}`}
            onClick={() => handleTabClick('reviews')}
            type="button"
            role="tab"
            aria-controls="reviews"
            aria-selected={activeTab === 'reviews'}
          >
            Reviews
          </button>
        </li>
      </ul>
      <div className="tab-content mt-3 mb-3" id="myTabContent">
        <div
          className={`tab-pane fade ${activeTab === 'additional' ? 'show active' : ''}`}
          id="additional"
          role="tabpanel"
          aria-labelledby="additional-tab"
        >
            {product && (
              <>
         {product.description}
         </>
        )}
        </div>
        <div
          className={`tab-pane fade ${activeTab === 'reviews' ? 'show active' : ''}`}
          id="reviews"
          role="tabpanel"
          aria-labelledby="reviews-tab"
        >
          
          Content for Reviews tab
        </div>
      </div>
    </div>
            </Container>
            <Footer />
        </div>
    );
};

export default SingleProductPage;
