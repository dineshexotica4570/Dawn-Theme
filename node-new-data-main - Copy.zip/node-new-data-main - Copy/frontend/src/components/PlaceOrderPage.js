import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import Header from './Header';
import Footer from './Footer';
import base_url from '../config';

const PlaceOrderPage = () => {
    const location = useLocation();
    const { order } = location.state;
    const [userData, setUserData] = useState(null);
    const [productNames, setProductNames] = useState({});

    const user = JSON.parse(localStorage.getItem('user')); 

    useEffect(() => {
        // Fetch user data
        fetch(`${base_url}/api/users/${user.userId}`)
            .then(response => response.json())
            .then(data => {
                setUserData(data);
            })
            .catch(error => console.error('Error fetching user data:', error));

        // Extract product IDs from order items
        const productIds = order.items.map(item => item.productId);

        fetch(`${base_url}/api/products/${productIds}`)
            .then(response => response.json())
            .then(data => {
                setProductNames(data.name);
            })
            .catch(error => console.error('Error fetching user data:', error));
    }, [order.items, user.userId]);

    return (
        <div>
            <Header />
            <div className="container mt-5 pt-4">
                <h2>Order Placed Successfully!</h2>
                <h5 className='mb-3'>Order Details:</h5>
                <ul className="list-group mb-3">
                    {order.items.map((item) => (
                        <li key={item._id} className="list-group-item d-flex justify-content-between">
                            <div>
                            <h6 className="my-0">{productNames[item.productId]}</h6>
                            <small className="text-muted">Quantity: {item.quantity}</small>
                            </div>
                            <span className="text-muted">${item.price * item.quantity}</span>
                        </li>
                    ))}

                    <li className="list-group-item d-flex justify-content-between">
                        <span>Total (USD)</span>
                        <strong>${order.total}</strong>
                    </li>
                </ul>
                <h5>User Details:</h5>
                {userData ? (
                    <div>
                        <p>Email: {userData.email}</p>
                        {/* Render other user details as needed */}
                    </div>
                ) : (
                    <p>Loading user data...</p>
                )}
                <p>Order Status: {order.status}</p>
            </div>
            <Footer />
        </div>
    );
};

export default PlaceOrderPage;
