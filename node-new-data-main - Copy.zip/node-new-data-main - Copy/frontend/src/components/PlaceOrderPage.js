import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import Header from './Header';
import Footer from './Footer';
import base_url from '../config';
import axios from 'axios';

const PlaceOrderPage = () => {
    const location = useLocation();
    const { order } = location.state;
    const [userData, setUserData] = useState(null);
    const [productNames, setProductNames] = useState({});
    const [addresses, setAddresses] = useState([]);
    const user = JSON.parse(localStorage.getItem('user'));

    useEffect(() => {
        // Fetch user data
        const fetchUserData = async () => {
            try {
                const response = await axios.get(`${base_url}/api/users/${user.userId}`);
                setUserData(response.data);
            } catch (error) {
                console.error('Error fetching user data:', error);
            }
        };

        // Fetch product names
        const fetchProductNames = async () => {
            const productIds = order.items.map(item => item.productId);
            try {
                const response = await axios.get(`${base_url}/api/products/${productIds.join(',')}`);
                setProductNames(response.data);
            } catch (error) {
                console.error('Error fetching product names:', error);
            }
        };

        // Fetch addresses
        const fetchAddresses = async () => {
            try {
                const response = await axios.get(`${base_url}/api/addresses/${user.userId}`);
                setAddresses(response.data);
            } catch (error) {
                console.error('Error fetching addresses:', error);
            }
        };

        fetchUserData();
        fetchProductNames();
        fetchAddresses();
    }, [order.items, user.userId]);

    return (
        <div>
            <Header />
            <div className="container mt-5 pt-4">
                <h2>Order Placed Successfully!</h2>
                <h5 className='mb-3'>Order Details:</h5>
                <ul className="list-group mb-3">
                    {order.items.map((item) => (
                        <li key={item._id} className="list-group-item d-flex justify-content-between">
                            <div>
                            <img src={`${base_url}/api/${productNames.image}`}  className="img-fluid mr-3" style={{ maxWidth: '50px' }} />
                                <h6 className="my-0">{productNames.name}</h6>
                                <small className="text-muted">Quantity: {item.quantity}</small>
                            </div>
                            <span className="text-muted">${item.price * item.quantity}</span>
                            
                        </li>
                    ))}
                    <li className="list-group-item d-flex justify-content-between">
                        <span>Total (USD)</span>
                        <strong>${order.total}</strong>
                    </li>
                </ul>
                <h5>User Details:</h5>
                {userData ? (
                    <div>
                        <p>Email: {userData.email}</p>
                        {/* Render other user details as needed */}
                    </div>
                ) : (
                    <p>Loading user data...</p>
                )}
                <h5>Shipping Address:</h5>
                {addresses.length > 0 ? (
                    <table className="table">
                        <thead>
                            <tr>
                                <th>Full Name</th>
                                <th>Address Line 1</th>
                                <th>Address Line 2</th>
                                <th>City</th>
                                <th>State</th>
                                <th>Zip</th>
                                <th>Country</th>
                            </tr>
                        </thead>
                        <tbody>
                            {addresses.map((address, index) => (
                                <tr key={index}>
                                    <td>{address.fullname}</td>
                                    <td>{address.addressLine1}</td>
                                    <td>{address.addressLine2 || '-'}</td>
                                    <td>{address.city}</td>
                                    <td>{address.state}</td>
                                    <td>{address.zip}</td>
                                    <td>{address.country}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                ) : (
                    <p>No shipping address found.</p>
                )}
                <p>Order Status: {order.status}</p>
            </div>
            <Footer />
        </div>
    );
};

export default PlaceOrderPage;
