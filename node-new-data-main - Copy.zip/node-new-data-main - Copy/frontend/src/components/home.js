import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Header from './Header';
import Footer from './Footer';
import { Card, Button, Carousel } from 'react-bootstrap';
import base_url from '../config';
import { Link } from 'react-router-dom';
const Home = () => {
    const [posts, setPosts] = useState([]);
    const [products, setProducts] = useState([]);

    useEffect(() => {
        const fetchPosts = async () => {
            try {
                const response = await axios.get(`${base_url}/api/posts`);
                setPosts(response.data);
            } catch (error) {
                console.error('Error fetching posts:', error);
            }
        };
        const fetchProducts = async () => {
            try {
                const response = await axios.get(`${base_url}/api/products`);
                setProducts(response.data);
            } catch (error) {
                console.error('Error fetching products:', error);
            }
        };

        fetchProducts();

        fetchPosts();
    }, []);

    const truncateText = (text, limit) => {
        const words = text.split(' ');
        if (words.length > limit) {
            return words.slice(0, limit).join(' ') + '...';
        }
        return text;
    };

    return (
        <div>
            <Header />
            <div className='banner-slider'>
            <Carousel>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="https://zoonix-backend.vercel.app/api/uploads/project-one-1.jpg"
          alt="First slide"
        />
        <Carousel.Caption className='position-absolute top-50 start-50"'>
          <h3 style={{ fontSize: '3rem' }}>First slide label</h3>
          <p style={{ fontSize: '1.25rem' }}>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="https://zoonix-backend.vercel.app/api/uploads/project-one-2.jpg"
          alt="Second slide"
        />
        <Carousel.Caption className='position-absolute top-50 start-50"'>
        <h3 style={{ fontSize: '3rem' }}>Second slide label</h3>
        <p style={{ fontSize: '1.25rem' }}>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="https://zoonix-backend.vercel.app/api/uploads/project-one-3.jpg"
          alt="Third slide"
        />
        <Carousel.Caption className='position-absolute top-50 start-50"'>
          <h3 style={{ fontSize: '3rem' }}>Third slide label</h3>
          <p style={{ fontSize: '1.25rem' }}>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
            </div>
            <div className="container">

                <h2 className="mt-5 mb-3.5" style={{ fontSize: '3rem' }}>Recent Blogs</h2>
                <div className="row">
                    {posts.map(post => (
                        <div key={post._id} className="col-md-3 mb-3 g-10">
                            <Card style={{ width: '17rem' }}>
                                {post.image && (
                                    <Card.Img variant="top" src={`${base_url}/api/${post.image}`} alt={post.name} style={{ maxHeight: '200px', objectFit: 'cover' }} />
                                )}
                                <Card.Body>
                                    <Card.Title>{post.name}</Card.Title>
                                    <Card.Text>
                                        {truncateText(post.description, 10)} 
                                    </Card.Text>
                                    <Link to={`/posts/singlepost/${post._id}`} className="btn btn-primary">Read More</Link>
                                </Card.Body>
                            </Card>
                        </div>
                    ))}
                    
                </div>
                <div className='banner-btn w-25 mx-auto'>
                      <Link className="btn btn-primary btn-lg mt-2 mb-3 d-block" to="/posts">More Posts</Link>
                      </div>                    
                <h2 className="mt-5 mb-3.5" style={{ fontSize: '3rem' }}>Recent Products</h2>
                <div className="row">
                    {products.map(product => (
                    <div key={product._id} className="col-md-3 mb-3 g-10">
                        <Card style={{ width: '17rem' }}>
                            {product.image && (
                                <Card.Img variant="top" src={`${base_url}/api/${product.image}`} alt={product.name} style={{ maxHeight: '200px', objectFit: 'cover' }} />
                            )}
                            <Card.Body>
                                <Card.Title>{product.name}</Card.Title>
                                <Card.Text>
                                    
                                </Card.Text>
                                <Link to={`/products/singleproduct/${product._id}`} className="btn btn-primary">Read More</Link>
                            </Card.Body>
                        </Card>
                    </div>
                    ))}
                                  

                </div>
                <div className='banner-btn w-25 mx-auto'>
                    <Link className="btn btn-primary btn-lg mt-2 mb-3 d-block" to="/shop">More Products</Link>
                    </div>    
            </div>
            <Footer />
        </div>
    );
};

export default Home;
