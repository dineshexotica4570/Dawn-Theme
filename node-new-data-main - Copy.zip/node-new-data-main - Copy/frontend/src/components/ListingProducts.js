import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, Pagination } from 'react-bootstrap';
import { Link } from 'react-router-dom';

import Header from './Header';
import Footer from './Footer';
import base_url from '../config';

const ListingProducts = () => {
    const [products, setProducts] = useState([]);
    const [categories, setCategories] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [selectedCategory, setSelectedCategory] = useState('');
    const productsPerPage = 10;

    useEffect(() => {
        const fetchCategories = async () => {
            try {
                const response = await axios.get(`${base_url}/api/product_cat`);
                setCategories(response.data);
            } catch (error) {
                console.error('Error fetching categories:', error);
            }
        };

        fetchCategories();
    }, []);

    useEffect(() => {
        const fetchProducts = async () => {
            try {
                let url = `${base_url}/api/products`;
                if (selectedCategory) {
                    url = `${base_url}/api/specific-cat/${selectedCategory}`;
                }
                const response = await axios.get(url);
                setProducts(response.data);
            } catch (error) {
                console.error('Error fetching products:', error);
            }
        };

        fetchProducts();
    }, [selectedCategory]);

    const truncateText = (text, limit) => {
        const words = text.split(' ');
        if (words.length > limit) {
            return words.slice(0, limit).join(' ') + '...';
        }
        return text;
    };

    const handleCategorySelect = (categoryId) => {
        setSelectedCategory(categoryId);
        setCurrentPage(1); // Reset pagination when selecting a category
    };

    // Logic for pagination
    const indexOfLastProduct = currentPage * productsPerPage;
    const indexOfFirstProduct = indexOfLastProduct - productsPerPage;
    const currentProducts = products.slice(indexOfFirstProduct, indexOfLastProduct);

    const paginate = (pageNumber) => setCurrentPage(pageNumber);

    return (
        <div>
            <Header />
            <div className="container pt-4">
                <h2 className="mt-5 mb-3.5" style={{ fontSize: '3rem' }}>Products</h2>

                {/* Category filters */}
                <div className="mb-3">
                    <strong>Filter by Category:</strong>{' '}
                    <button
                        className={`btn btn-sm mx-1 ${selectedCategory === '' ? 'btn-primary' : 'btn-outline-primary'}`}
                        onClick={() => handleCategorySelect('')}
                    >
                        All
                    </button>
                    {categories.map(category => (
                        <button
                            key={category._id}
                            className={`btn btn-sm mx-1 ${selectedCategory === category._id ? 'btn-primary' : 'btn-outline-primary'}`}
                            onClick={() => handleCategorySelect(category._id)}
                        >
                            {category.name}
                        </button>
                    ))}
                   
                </div>

                {/* Product cards */}
                <div className="row">
                    {currentProducts.map(product => (
                        <div key={product._id} className="col-md-4 mb-4">
                            <Card style={{ width: '18rem' }}>
                                {product.image && (
                                    <Card.Img
                                        variant="top"
                                        src={`${base_url}/api/${product.image}`}
                                        alt={product.name}
                                        style={{ maxHeight: '200px', objectFit: 'cover' }}
                                    />
                                )}
                                <Card.Body>
                                    <Card.Title>{product.name}</Card.Title>
                                    <Card.Text>
                                        {truncateText(product.description, 10)}
                                    </Card.Text>
                                    <Card.Text>
                                        <strong>Price: </strong>${product.price}
                                    </Card.Text>
                                    <Link to={`/products/singleproduct/${product._id}`} className="btn btn-primary">
                                        View Details
                                    </Link>
                                </Card.Body>
                            </Card>
                        </div>
                    ))}
                </div>

                {/* Pagination */}
                <Pagination className="mt-3 justify-content-center">
                    <Pagination.Prev onClick={() => paginate(currentPage - 1)} disabled={currentPage === 1} />
                    {Array.from({ length: Math.ceil(products.length / productsPerPage) }, (_, index) => (
                        <Pagination.Item
                            key={index + 1}
                            onClick={() => paginate(index + 1)}
                            active={index + 1 === currentPage}
                        >
                            {index + 1}
                        </Pagination.Item>
                    ))}
                    <Pagination.Next
                        onClick={() => paginate(currentPage + 1)}
                        disabled={currentPage === Math.ceil(products.length / productsPerPage)}
                    />
                </Pagination>
            </div>

            <Footer />
        </div>
    );
};

export default ListingProducts;
