import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, Button, Pagination } from 'react-bootstrap';
import { Link } from 'react-router-dom';

import Header from './Header';
import Footer from './Footer';

const ListingPosts = () => {
    const [posts, setPosts] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const postsPerPage = 10;

    useEffect(() => {
        const fetchPosts = async () => {
            try {
                const response = await axios.get('http://localhost:5000/api/posts');
                setPosts(response.data);
            } catch (error) {
                console.error('Error fetching posts:', error);
            }
        };

        fetchPosts();
    }, []);

    const truncateText = (text, limit) => {
        const words = text.split(' ');
        if (words.length > limit) {
            return words.slice(0, limit).join(' ') + '...';
        }
        return text;
    };

    // Logic for pagination
    const indexOfLastPost = currentPage * postsPerPage;
    const indexOfFirstPost = indexOfLastPost - postsPerPage;
    const currentPosts = posts.slice(indexOfFirstPost, indexOfLastPost);

    const paginate = (pageNumber) => setCurrentPage(pageNumber);

    return (
        <div>
            <Header />
            <div className="container pt-4">
                
                <h2 className="mt-5 mb-3.5" style={{ fontSize: '3rem' }}>Blogs</h2>
                <div className="row">
                    {currentPosts.map(post => (
                        <div key={post._id} className="col-md-3 mb-3 g-10">
                            <Card style={{ width: '17rem' }}>
                                {post.image && (
                                    <Card.Img variant="top" src={`http://localhost:5000/api/${post.image}`} alt={post.name} style={{ maxHeight: '200px', objectFit: 'cover' }} />
                                )}
                                <Card.Body>
                                    <Card.Title>{post.name}</Card.Title>
                                    <Card.Text>
                                        {truncateText(post.description, 10)}
                                    </Card.Text>
                                    <Link to={`/posts/singlepost/${post._id}`} className="btn btn-primary">Read More</Link>
                                </Card.Body>
                            </Card>
                        </div>
                    ))}
                </div>

                {/* Pagination */}
                <Pagination className="mt-3 justify-content-center">
                    <Pagination.Prev onClick={() => paginate(currentPage - 1)} disabled={currentPage === 1} />
                    {Array.from({ length: Math.ceil(posts.length / postsPerPage) }, (_, index) => (
                        <Pagination.Item key={index + 1} onClick={() => paginate(index + 1)} active={index + 1 === currentPage}>
                            {index + 1}
                        </Pagination.Item>
                    ))}
                    <Pagination.Next onClick={() => paginate(currentPage + 1)} disabled={currentPage === Math.ceil(posts.length / postsPerPage)} />
                </Pagination>
            </div>

            <Footer />
        </div>
    );
};

export default ListingPosts;
