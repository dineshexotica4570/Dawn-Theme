import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Header from './Header';
import Footer from './Footer';
import { Card, Pagination } from 'react-bootstrap';
import base_url from '../config';
import { Link } from 'react-router-dom';

const ListingProductCategories = () => {
    const [categories, setCategories] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const categoriesPerPage = 8; // Adjust based on your design

    useEffect(() => {
        const fetchCategories = async () => {
            try {
                const response = await axios.get(`${base_url}/api/product_cat`);
                setCategories(response.data); // Slice to limit initial display
            } catch (error) {
                console.error('Error fetching categories:', error);
            }
        };

        fetchCategories();
    }, []);

    // Logic for pagination
    const indexOfLastCategory = currentPage * categoriesPerPage;
    const indexOfFirstCategory = indexOfLastCategory - categoriesPerPage;
    const currentCategories = categories.slice(indexOfFirstCategory, indexOfLastCategory);

    const paginate = (pageNumber) => setCurrentPage(pageNumber);

    return (
        <div>
            <Header />
            <div className="container pt-4">
                <h2 className="mt-5 mb-3.5" style={{ fontSize: '3rem' }}>Product Categories</h2>
                <div className="row">
                    {currentCategories.map(category => (
                        <div key={category._id} className="col-md-3 mb-3 g-10">
                            <Card style={{ width: '17rem' }}>
                                {/* Assuming category image and name fields */}
                                <Card.Img variant="top" src={`${base_url}/api/${category.image}`} alt={category.name} style={{ maxHeight: '200px', objectFit: 'cover' }} />
                                <Card.Body>
                                    <Card.Title>{category.name}</Card.Title>
                                    <Link to={`/product-categories/${category._id}`} className="btn btn-primary">View Category</Link>
                                </Card.Body>
                            </Card>
                        </div>
                    ))}
                </div>

                {/* Pagination */}
                <Pagination className="mt-3 justify-content-center">
                    <Pagination.Prev onClick={() => paginate(currentPage - 1)} disabled={currentPage === 1} />
                    {Array.from({ length: Math.ceil(categories.length / categoriesPerPage) }, (_, index) => (
                        <Pagination.Item key={index + 1} onClick={() => paginate(index + 1)} active={index + 1 === currentPage}>
                            {index + 1}
                        </Pagination.Item>
                    ))}
                    <Pagination.Next onClick={() => paginate(currentPage + 1)} disabled={currentPage === Math.ceil(categories.length / categoriesPerPage)} />
                </Pagination>
            </div>

            <Footer />
        </div>
    );
};

export default ListingProductCategories;
