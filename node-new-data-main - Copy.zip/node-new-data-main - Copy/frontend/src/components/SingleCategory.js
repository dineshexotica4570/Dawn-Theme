import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Header from './Header';
import Footer from './Footer';
import { Card, Row, Col } from 'react-bootstrap'; // assuming you are using react-bootstrap
import { useParams, Link } from 'react-router-dom';
import base_url from '../config';

const SingleCategory = () => {
    const [category, setCategory] = useState({});
    const [products, setProducts] = useState([]);
    const { id } = useParams();

    useEffect(() => {
        const fetchCategory = async () => {
            try {
                const response = await axios.get(`${base_url}/api/categories/${id}`);
                setCategory(response.data);
            } catch (error) {
                console.error('Error fetching category:', error);
            }
        };

        fetchCategory();
    }, [id]);

    useEffect(() => {
        const fetchProducts = async () => {
            try {
                const response = await axios.get(`${base_url}/api/specific-cat/${id}`);
                setProducts(response.data);
            } catch (error) {
                console.error('Error fetching products:', error);
            }
        };

        fetchProducts();
    }, [id]);

    return (
        <div>
            <Header />
            <div className="container pt-4">
                <h2 className="mt-5 mb-3.5" style={{ fontSize: '3rem' }}>Category Details</h2>
                <div className="row">
                    <div className="col-md-12">
                        <Card>
                            {category.image && (
                                <Card.Img
                                    variant="top"
                                    src={`${base_url}/api/${category.image}`}
                                    alt={category.name}
                                    style={{ maxHeight: '400px', objectFit: 'cover' }}
                                />
                            )}
                            <Card.Body>
                                <Card.Title>{category.name}</Card.Title>
                                <Card.Text>{category.description}</Card.Text>
                            </Card.Body>
                        </Card>
                    </div>
                </div>

                <h2 className="mt-5 mb-3.5" style={{ fontSize: '3rem' }}>Products</h2>
                <Row>
                    {products.map(product => (
                        <Col md={4} key={product._id}>
                            <Card className="mb-4">
                                {/* Assuming you have a product image */}
                                {product.image && (
                                    <Card.Img
                                        variant="top"
                                        src={`${base_url}/api/${product.image}`}
                                        alt={product.name}
                                        style={{ maxHeight: '200px', objectFit: 'cover' }}
                                    />
                                )}
                                <Card.Body>
                                    <Card.Title>{product.name}</Card.Title>
                                    <Card.Text>
                                        {/* Display other product details */}
                                        Price: ${product.price}
                                    </Card.Text>
                                    <Link to={`/products/singleproduct/${product._id}`} className="btn btn-primary">View Details</Link>
                                </Card.Body>
                            </Card>
                        </Col>
                    ))}
                </Row>
            </div>
            <Footer />
        </div>
    );
};

export default SingleCategory;
