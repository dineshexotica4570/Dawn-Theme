import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Register from './components/Register';
import Login from './components/Login';
import Home from './components/home';
import Dashboard from './components/Dashboard';
import ListingPosts from './components/ListingPosts';
import PlaceOrderPage from './components/PlaceOrderPage';
import ListingProducts from './components/ListingProducts';
import ListingProductCategories from './components/ListingProductCategories';
import SinglePost from './components/SinglePost';
import SingleCategory from './components/SingleCategory';
import Posts from './components/admin/Posts';
import Products from './components/admin/Products';
import AddressForm from './components/admin/AddressForm';
import OrdersListing from './components/admin/OrdersListing';
import ProtectedRoute from './components/ProtectedRoute';
import MainLayout from './components/admin/MainLayout';
import Users from './components/admin/Users';
import ProfileEdit from './components/admin/ProfileEdit';
import ProductCategories from './components/admin/ProductCategories';
import SingleProductPage from './components/SingleProductPage';
import CartPage from './components/CartPage';
import CheckoutPage from './components/CheckoutPage';
import base_url from './config';
const App = () => {
    const [userRole, setUserRole] = useState('');

    useEffect(() => {
        const user = JSON.parse(localStorage.getItem('user'));

        if (user) {
            fetch(`${base_url}/api/users/${user.userId}`)
                .then(response => response.json())
                .then(data => {
                    setUserRole(data.role); // Assuming role is returned from API
                })
                .catch(error => console.error('Error fetching user data:', error));
        }
    }, []);

    return (
        <Router>
            <Routes>
                <Route path="/register" element={<Register />} />
                <Route path="/login" element={<Login />} />
                <Route path="/posts" element={<ListingPosts />} />
                <Route path="/shop" element={<ListingProducts />} />
                <Route path="/product-categories" element={<ListingProductCategories />} />

                <Route path="/products/singleproduct/:id" element={<SingleProductPage />} />
                <Route path="/product-categories/:id" element={<SingleCategory />} />
                <Route path="/cart" element={<CartPage />} />
                <Route path="/checkout" element={<CheckoutPage />} />
                <Route path="/place-order" element={<PlaceOrderPage />} />

                <Route path="/posts/singlepost/:id" element={<SinglePost />} />
                <Route path="/" element={<Home />} />

                {userRole === 'Admin' ? (
                    <Route path="/" element={<ProtectedRoute element={MainLayout} userRole={userRole} />}>
                        <Route path="/dashboard" element={<Dashboard />} />
                        <Route path="/dashboard/posts" element={<Posts />} />
                        <Route path="/dashboard/products" element={<Products />} />
                        <Route path="/dashboard/categories" element={<ProductCategories />} />
                        <Route path="/dashboard/orders" element={<OrdersListing />} />
                        <Route path="/dashboard/users" element={<Users />} />
                        <Route path="/dashboard/profile" element={<ProfileEdit />} />
                        <Route path="/dashboard/address" element={<AddressForm />} />
                        {/* Add more nested routes here */}
                    </Route>
                ) : (
                    <Route path="/" element={<ProtectedRoute element={MainLayout} userRole={userRole} />}>
                        <Route path="/dashboard" element={<Dashboard />} />
                        <Route path="/dashboard/orders" element={<OrdersListing />} />
                        <Route path="/dashboard/profile" element={<ProfileEdit />} />
                        <Route path="/dashboard/address" element={<AddressForm />} />
                        {/* Add more non-admin routes here */}
                    </Route>
                )}
            </Routes>
        </Router>
    );
};

export default App;
