// config.js

const base_url = 'http://localhost:5000';

export default base_url;
