import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import base_url from '../../config';

// Async thunk to fetch product categories
export const fetchProductCategories = createAsyncThunk('products/fetchProductCategories', async () => {
    try {
        const response = await axios.get(`${base_url}/api/product_cat`);
        return response.data;
    } catch (error) {
        throw Error(error.response.data.message);
    }
});
// // Async thunk to fetch category by ID
// export const fetchCategoryById = createAsyncThunk(
//     'categories/fetchCategoryById',
//     async (categoryId) => {
//         try {
//             const response = await axios.get(`${base_url}/api/categories/${categoryId}`);
//             return response.data;
//         } catch (error) {
//             throw Error(error.response.data.message);
//         }
//     }
// );


export const fetchProductById = createAsyncThunk('products/fetchProductById', async (id) => {
    try {
        const response = await axios.get(`${base_url}/api/products/${id}`);
        return response.data; 
    } catch (error) {
        throw Error(error.response.data.message); 
    }
});

export const fetchProducts = createAsyncThunk('products/fetchProducts', async () => {
    try {
        const response = await axios.get(`${base_url}/api/products/`);
        return response.data; 
    } catch (error) {
        throw Error(error.response.data.message); 
    }
});

export const addProduct = createAsyncThunk('products/addProduct', async (newProduct) => {
    const formData = new FormData();
    formData.append('name', newProduct.name);
    formData.append('description', newProduct.description);
    formData.append('quantity', newProduct.quantity);
    formData.append('price', newProduct.price);
    formData.append('image', newProduct.image);
    formData.append('categoryId', newProduct.category); // Add category ID to FormData

    const response = await axios.post(`${base_url}/api/products`, formData);
    return response.data;
});

export const updateProduct = createAsyncThunk('products/updateProduct', async (updatedProduct) => {
    const formData = new FormData();
    formData.append('name', updatedProduct.name);
    formData.append('description', updatedProduct.description);
    formData.append('price', updatedProduct.price);
    formData.append('quantity', updatedProduct.quantity);
    if (updatedProduct.image) {
        formData.append('image', updatedProduct.image);
    }
    formData.append('categoryId', updatedProduct.category); // Add category ID to FormData

    const response = await axios.put(`${base_url}/api/products/${updatedProduct._id}`, formData);
    return response.data;
});

export const deleteProduct = createAsyncThunk('products/deleteProduct', async (id) => {
    await axios.delete(`${base_url}/api/products/${id}`);
    return id;
});

const productsSlice = createSlice({
    name: 'products',
    initialState: {
        products: [],
        productCategories: [],
       // categoryById : [],
        status: 'idle',
        error: null,
    },
    reducers: {},
    extraReducers: (builder) => {
        builder

        // .addCase(fetchCategoryById.pending, (state) => {
        //     state.status = 'loading';
        // })
        // .addCase(fetchCategoryById.fulfilled, (state, action) => {
        //     state.status = 'succeeded';
        //     // Assuming you have a specific category state
        //     state.selectedCategory = action.payload;
        // })
        // .addCase(fetchCategoryById.rejected, (state, action) => {
        //     state.status = 'failed';
        //     state.error = action.error.message;
        // })
            .addCase(fetchProductCategories.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(fetchProductCategories.fulfilled, (state, action) => {
                state.status = 'succeeded';
                state.productCategories = action.payload; // Store fetched categories
            })
            .addCase(fetchProductCategories.rejected, (state, action) => { // Fix: Changed fetchCategories.rejected to fetchProductCategories.rejected
                state.status = 'failed';
                state.error = action.error.message;
            })
            .addCase(fetchProductById.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(fetchProductById.fulfilled, (state, action) => {
                state.status = 'succeeded';
                state.product = action.payload;
            })
            .addCase(fetchProductById.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.error.message;
            })
            .addCase(fetchProducts.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(fetchProducts.fulfilled, (state, action) => {
                state.status = 'succeeded';
                state.products = action.payload;
            })
            .addCase(fetchProducts.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.error.message;
            })
            .addCase(addProduct.fulfilled, (state, action) => {
                state.products.push(action.payload);
            })
            .addCase(updateProduct.fulfilled, (state, action) => {
                const index = state.products.findIndex(product => product._id === action.payload._id);
                state.products[index] = action.payload;
            })
            .addCase(deleteProduct.fulfilled, (state, action) => {
                state.products = state.products.filter(product => product._id !== action.payload);
            });
    },
});

export const selectProductCategories = (state) => state.products.productCategories;
export default productsSlice.reducer;
