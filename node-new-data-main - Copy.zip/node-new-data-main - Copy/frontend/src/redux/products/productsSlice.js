import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import base_url from '../../config';



export const fetchProductById = createAsyncThunk('products/fetchProductById', async (id) => {
    try {
        const response = await axios.get(`${base_url}/api/products/${id}`);
        return response.data; 
    } catch (error) {
        throw Error(error.response.data.message); 
    }
});
// Thunks for asynchronous actions
export const fetchProducts = createAsyncThunk('products/fetchProducts', async () => {
    try {
        const response = await axios.get(`${base_url}/api/products/`);
        return response.data; 
    } catch (error) {
        throw Error(error.response.data.message); 
    }
});


export const addProduct = createAsyncThunk('products/addProduct', async (newProduct) => {
    const formData = new FormData();
    formData.append('name', newProduct.name);
    formData.append('description', newProduct.description);
    formData.append('quantity', newProduct.quantity);
    formData.append('price', newProduct.price);
    formData.append('image', newProduct.image);

    const response = await axios.post(`${base_url}/api/products`, formData);
    return response.data;
});

export const updateProduct = createAsyncThunk('products/updateProduct', async (updatedProduct) => {
    const formData = new FormData();
    formData.append('name', updatedProduct.name);
    formData.append('description', updatedProduct.description);
    formData.append('price', updatedProduct.price);
    formData.append('quantity', updatedProduct.quantity);
    if (updatedProduct.image) {
        formData.append('image', updatedProduct.image);
    } 
    /*else {
        formData.append('currentImage', updatedProduct.currentImage);
    }*/

    const response = await axios.put(`${base_url}/api/products/${updatedProduct._id}`, formData);
    return response.data;
});

export const deleteProduct = createAsyncThunk('products/deleteProduct', async (id) => {
    await axios.delete(`${base_url}/api/products/${id}`);
    return id;
});

const productsSlice = createSlice({
    name: 'products',
    initialState: {
        products: [],
        status: 'idle',
        error: null,
    },
    reducers: {},
    extraReducers: (builder) => {
        builder

        .addCase(fetchProductById.pending, (state) => {
            state.status = 'loading';
        })
        .addCase(fetchProductById.fulfilled, (state, action) => {
            state.status = 'succeeded';
            state.product = action.payload;
        })
        .addCase(fetchProductById.rejected, (state, action) => {
            state.status = 'failed';
            state.error = action.error.message;
        })
            .addCase(fetchProducts.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(fetchProducts.fulfilled, (state, action) => {
                state.status = 'succeeded';
                state.products = action.payload;
            })
            .addCase(fetchProducts.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.error.message;
            })
            .addCase(addProduct.fulfilled, (state, action) => {
                state.products.push(action.payload);
            })
            .addCase(updateProduct.fulfilled, (state, action) => {
                const index = state.products.findIndex(product => product._id === action.payload._id);
                state.products[index] = action.payload;
            })
            .addCase(deleteProduct.fulfilled, (state, action) => {
                state.products = state.products.filter(product => product._id !== action.payload);
            });
    },
});

export default productsSlice.reducer;
