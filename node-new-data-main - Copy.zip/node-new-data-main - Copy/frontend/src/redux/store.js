// store.js
import { configureStore } from '@reduxjs/toolkit';
import productsReducer from './products/productsSlice';
import cartReducer from './products/cartSlice';

const loadState = () => {
    try {
        const serializedState = localStorage.getItem('cartState');
        if (serializedState === null) {
            return undefined;
        }
        return JSON.parse(serializedState);
    } catch (err) {
        return undefined;
    }
};

const saveState = (state) => {
    try {
        const serializedState = JSON.stringify(state.cart);
        localStorage.setItem('cartState', serializedState);
    } catch (err) {
        // Ignore write errors
    }
};

const store = configureStore({
    reducer: {
        products: productsReducer,
        cart: cartReducer,
    },
    preloadedState: {
        cart: loadState(),
    },
});

store.subscribe(() => {
    saveState(store.getState());
});

export default store;
