const mongoose = require('mongoose');

const ProductCategories = new mongoose.Schema({
    name: String,
    description: String,
    image: String
});

const ProductCategoryModel = mongoose.model('ProductCategories', ProductCategories);
module.exports = ProductCategoryModel;
