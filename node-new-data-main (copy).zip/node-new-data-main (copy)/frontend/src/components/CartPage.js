import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';
import { Table, Button } from 'react-bootstrap';
import { removeItemFromCart, clearCart } from '../redux/products/cartSlice';
import Header from './Header';
import Footer from './Footer';

const CartPage = () => {
    const dispatch = useDispatch();
    const items = useSelector((state) => state.cart.items);
console.log(items);
    const handleRemoveFromCart = (id) => {
        dispatch(removeItemFromCart(id));
    };

    const handleClearCart = () => {
        dispatch(clearCart());
    };

    return (
        <div>
            <Header />
        <div className="container mt-5">
            <h2>Your Cart</h2>
            <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {items.map((item) => (
                        <tr key={item._id}>
                            <td>{item.name}</td>
                            <td>{item.quantity}</td>
                            <td>${item.price}</td>
                            <td>
                                <Button variant="danger" onClick={() => handleRemoveFromCart(item._id)}>Remove</Button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </Table>
            <Button variant="secondary" onClick={handleClearCart}>Clear Cart</Button>
            <Link to="/checkout" className="btn btn-primary ml-3">Proceed to Checkout</Link>
        </div>
        <Footer />
        </div>
    );
};

export default CartPage;
