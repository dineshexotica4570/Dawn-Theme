import React from 'react';
import { useSelector, useDispatch } from 'react-redux';

import { clearCart } from '../redux/products/cartSlice';
import Header from './Header';
import Footer from './Footer';

const CheckoutPage = () => {
    const dispatch = useDispatch();

    const items = useSelector((state) => state.cart.items);
    
    // Calculate total properly
    const total = items.reduce((acc, item) => acc + (item.price * item.quantity), 0);

    const handleCheckout = () => {
        dispatch(clearCart());
    };

    return (
        <div>
            <Header />
            <div className="container mt-5">
                <h2>Checkout</h2>
                <ul className="list-group mb-3">
                    {items.map((item) => (
                        <li key={item._id} className="list-group-item d-flex justify-content-between">
                            <div>
                                <h6 className="my-0">{item.name}</h6>
                                <small className="text-muted">Quantity: {item.quantity}</small>
                            </div>
                            <span className="text-muted">${item.price * item.quantity}</span>
                        </li>
                    ))}
                    <li className="list-group-item d-flex justify-content-between">
                        <span>Total (USD)</span>
                        <strong>${total}</strong>
                    </li>
                </ul>
                <button className="btn btn-primary btn-lg btn-block" onClick={handleCheckout}>Place Order</button>
            </div>
            <Footer />
        </div>
    );
};

export default CheckoutPage;
