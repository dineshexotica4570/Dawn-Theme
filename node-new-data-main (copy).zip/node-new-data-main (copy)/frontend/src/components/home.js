import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Header from './Header';
import Footer from './Footer';
import { Card, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
const Home = () => {
    const [posts, setPosts] = useState([]);

    useEffect(() => {
        const fetchPosts = async () => {
            try {
                const response = await axios.get('http://localhost:5000/api/posts');
                setPosts(response.data);
            } catch (error) {
                console.error('Error fetching posts:', error);
            }
        };

        fetchPosts();
    }, []);

    const truncateText = (text, limit) => {
        const words = text.split(' ');
        if (words.length > limit) {
            return words.slice(0, limit).join(' ') + '...';
        }
        return text;
    };

    return (
        <div>
            <Header />
            <div className="container">
                <h2 className="mt-3 mb-3">Welcome to your Home Page</h2>
                <div className="row">
                    {posts.map(post => (
                        <div key={post._id} className="col-md-4 mb-4">
                            <Card style={{ width: '18rem' }}>
                                {post.image && (
                                    <Card.Img variant="top" src={`http://localhost:5000/${post.image}`} alt={post.name} style={{ maxHeight: '200px', objectFit: 'cover' }} />
                                )}
                                <Card.Body>
                                    <Card.Title>{post.name}</Card.Title>
                                    <Card.Text>
                                        {truncateText(post.description, 10)} 
                                    </Card.Text>
                                    <Link to={`/posts/singlepost/${post._id}`} className="btn btn-primary">Read More</Link>
                                </Card.Body>
                            </Card>
                        </div>
                    ))}
                     <Link className="primary" to="/posts">More Posts</Link>
                </div>
            </div>
            <Footer />
        </div>
    );
};

export default Home;
