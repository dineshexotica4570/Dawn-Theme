import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Table, Button, Modal, Form, Pagination, Row, Col } from 'react-bootstrap'; // Import Row and Col from react-bootstrap


const Posts = () => {
    const [posts, setPosts] = useState([]);
    const [showAddModal, setShowAddModal] = useState(false);
    const [showEditModal, setShowEditModal] = useState(false);
    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [newPost, setNewPost] = useState({ name: '', description: '', image: null });
    const [editPost, setEditPost] = useState({ _id: '', name: '', description: '', currentImage: '', image: null });
    const [deletePostId, setDeletePostId] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [searchQuery, setSearchQuery] = useState('');
    const postsPerPage = 8;

    const handleAddClose = () => setShowAddModal(false);
    const handleAddShow = () => setShowAddModal(true);
    const handleEditClose = () => setShowEditModal(false);
    const handleEditShow = (post) => {
        setEditPost({ ...post, currentImage: `http://localhost:5000/${post.image}`, image: null });
        setShowEditModal(true);
    };
    const handleDeleteClose = () => setShowDeleteModal(false);
    const handleDeleteShow = (postId) => {
        setDeletePostId(postId);
        setShowDeleteModal(true);
    };

    useEffect(() => {
        const fetchPosts = async () => {
            const response = await axios.get('http://localhost:5000/api/posts');
            setPosts(response.data);
        };
        fetchPosts();
    }, []);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setNewPost({ ...newPost, [name]: value });
    };

    const handleEditInputChange = (e) => {
        const { name, value } = e.target;
        setEditPost({ ...editPost, [name]: value });
    };

    const handleFileChange = (e) => {
        setNewPost({ ...newPost, image: e.target.files[0] });
    };

    const handleEditFileChange = (e) => {
        setEditPost({ ...editPost, image: e.target.files[0] });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const formData = new FormData();
        formData.append('name', newPost.name);
        formData.append('description', newPost.description);
        formData.append('image', newPost.image);

        await axios.post('http://localhost:5000/api/posts', formData);
        handleAddClose();
        const response = await axios.get('http://localhost:5000/api/posts');
        setPosts(response.data);
        resetForm();
    };
    const resetForm = () => {
        setNewPost({ name: '', description: '', image: null });
    };
    const handleEditSubmit = async (e) => {
        e.preventDefault();
        const formData = new FormData();
        formData.append('name', editPost.name);
        formData.append('description', editPost.description);
        if (editPost.image) {
            formData.append('image', editPost.image);
        }

        await axios.put(`http://localhost:5000/api/posts/${editPost._id}`, formData);
        handleEditClose();
        const response = await axios.get('http://localhost:5000/api/posts');
        setPosts(response.data);
    };

    const handleDelete = async () => {
        try {
            await axios.delete(`http://localhost:5000/api/posts/${deletePostId}`);
            handleDeleteClose();
            const response = await axios.get('http://localhost:5000/api/posts');
            setPosts(response.data);
        } catch (error) {
            console.error('Error deleting the post', error);
        }
    };

    const handleSearchInputChange = (e) => {
        setSearchQuery(e.target.value);
    };

    // Filtering posts based on search query
    const filteredPosts = posts.filter((post) =>
        post.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        post.description.toLowerCase().includes(searchQuery.toLowerCase())
    );

    // Pagination Logic for filtered posts
    const indexOfLastPost = currentPage * postsPerPage;
    const indexOfFirstPost = indexOfLastPost - postsPerPage;
    const currentPosts = filteredPosts.slice(indexOfFirstPost, indexOfLastPost);

    const paginate = (pageNumber) => setCurrentPage(pageNumber);

    return (
        <div>
            <h2>Posts Page</h2>
            
            <Row className="mb-3">
                <Col>
                    <Button variant="primary" onClick={handleAddShow}>
                        Add New
                    </Button>
                </Col>
                <Col>
                <Form.Group controlId="formSearch">
                <Form.Control
                    type="text"
                    placeholder="Search Posts by name or description"
                    value={searchQuery}
                    onChange={handleSearchInputChange}
                />
            </Form.Group>
                </Col>
            </Row>
            <Table striped bordered hover className="mt-3">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Image</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {currentPosts.map((post) => (
                        <tr key={post._id}>
                            <td>{post.name}</td>
                            <td>{post.description}</td>
                            <td><img src={`http://localhost:5000/${post.image}`} alt={post.name} style={{ width: '100px' }} /></td>
                            <td>
                                <div className="actions">
                                <Button variant="warning" className="mr-2" onClick={() => handleEditShow(post)}>Edit</Button>
                                <Button variant="danger" onClick={() => handleDeleteShow(post._id)}>Delete</Button>
                                </div>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </Table>

            {/* Pagination Component */}
            <Pagination className="mt-3">
                <Pagination.Prev onClick={() => paginate(currentPage - 1)} disabled={currentPage === 1} />
                {Array.from({ length: Math.ceil(filteredPosts.length / postsPerPage) }, (_, index) => (
                    <Pagination.Item key={index + 1} onClick={() => paginate(index + 1)} active={index + 1 === currentPage}>
                        {index + 1}
                    </Pagination.Item>
                ))}
                <Pagination.Next onClick={() => paginate(currentPage + 1)} disabled={currentPage === Math.ceil(filteredPosts.length / postsPerPage)} />
            </Pagination>

            {/* Add Post Modal */}
            <Modal show={showAddModal} onHide={handleAddClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Add New Post</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={handleSubmit}>
                        <Form.Group controlId="formName">
                            <Form.Label>Name</Form.Label>
                            <Form.Control
                                type="text"
                                name="name"
                                value={newPost.name}
                                onChange={handleInputChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group controlId="formDescription">
                            <Form.Label>Description</Form.Label>
                            <Form.Control
                                as="textarea"
                                rows={3}
                                name="description"
                                value={newPost.description}
                                onChange={handleInputChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group controlId="formImage">
                            <Form.Label>Image</Form.Label>
                            <Form.Control
                                type="file"
                                name="image"
                                onChange={handleFileChange}
                                required
                            />
                        </Form.Group>
                        <Button variant="primary" type="submit" className="mt-3">
                            Save Post
                        </Button>
                    </Form>
                </Modal.Body>
            </Modal>

            {/* Edit Post Modal */}
            <Modal show={showEditModal} onHide={handleEditClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Edit Post</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={handleEditSubmit}>
                        <Form.Group controlId="editFormName">
                            <Form.Label>Name</Form.Label>
                            <Form.Control
                                type="text"
                                name="name"
                                value={editPost.name}
                                onChange={handleEditInputChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group controlId="editFormDescription">
                            <Form.Label>Description</Form.Label>
                            <Form.Control
                                as="textarea"
                                rows={3}
                                name="description"
                                value={editPost.description}
                                onChange={handleEditInputChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group controlId="editFormCurrentImage">
                            <Form.Label>Current Image</Form.Label>
                            <br />
                            {editPost.currentImage && (
                                <img
                                    src={editPost.currentImage}
                                    alt="Current"
                                    style={{ width: '100px' }}
                                />
                            )}
                        </Form.Group>
                        <Form.Group controlId="editFormImage">
                            <Form.Label>New Image</Form.Label>
                            <Form.Control
                                type="file"
                                name="image"
                                onChange={handleEditFileChange}
                            />
                        </Form.Group>
                        <Button variant="primary" type="submit" className="mt-3">
                            Update Post
                        </Button>
                    </Form>
                </Modal.Body>
            </Modal>

            {/* Delete Confirmation Modal */}
            <Modal show={showDeleteModal} onHide={handleDeleteClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Delete Confirmation</Modal.Title>
                </Modal.Header>
                <Modal.Body>Are you sure you want to delete this post?</Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleDeleteClose}>
                        Cancel
                    </Button>
                    <Button variant="danger" onClick={handleDelete}>
                        Delete
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
};

export default Posts;
