import React from 'react';
import { Nav, Button } from 'react-bootstrap';
import { useNavigate, Link } from 'react-router-dom';

const Sidebar = () => {
    const navigate = useNavigate();

    const handleLogout = () => {
        localStorage.removeItem('user');
        navigate('/login');
    };

    return (
        <div className="bg-light sidebar-sticky">
            <h3 className="text-center mt-3">Dashboard</h3>
            <h6 className="text-center mt-3"><Link to="/">View Site</Link></h6>
            <Nav className="flex-column mt-4">
            <Link to="/dashboard">Dashboard</Link>
            <Link to="/dashboard/posts">Posts</Link>
            <Link to="/dashboard/products">Products</Link>   
            </Nav>
            <Button variant="danger" className="mt-4" onClick={handleLogout}>Logout</Button>
        </div>
    );
};

export default Sidebar;
