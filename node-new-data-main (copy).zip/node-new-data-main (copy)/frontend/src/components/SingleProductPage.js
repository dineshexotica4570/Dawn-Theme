import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import { fetchProductById } from '../redux/products/productsSlice';
import { addItemToCart } from '../redux/products/cartSlice';
import { Card, Button, Form } from 'react-bootstrap';
import Header from './Header';
import Footer from './Footer';

const SingleProductPage = () => {
    const { id } = useParams();
    const dispatch = useDispatch();
    const { product, status, error } = useSelector((state) => state.products);
    const [quantity, setQuantity] = useState(1);
    const [availableQuantity, setAvailableQuantity] = useState(0);

    useEffect(() => {
        dispatch(fetchProductById(id));
    }, [dispatch, id]);

    useEffect(() => {
        if (product) {
            setAvailableQuantity(product.quantity);
        }
    }, [product]);

    const handleAddToCart = () => {
        dispatch(addItemToCart({ ...product, quantity, id })); 
        console.log(`Added to Cart: ${product.name}, Quantity: ${quantity}, id: ${id}`); 
    };

    const handleQuantityChange = (e) => {
        const value = parseInt(e.target.value, 10);
        if (!isNaN(value) && value >= 1) {
            setQuantity(value);
        }
    };

    if (status === 'loading') {
        return <div>Loading...</div>;
    }

    if (status === 'failed') {
        return <div>{error}</div>;
    }

    return (
        <div>
            <Header />
        <div className="container mt-5">
            {product && (
                <Card>
                    <Card.Img variant="top" src={`http://localhost:5000/${product.image}`} />
                    <Card.Body>
                        <Card.Title>{product.name}</Card.Title>
                        <Card.Text>{product.description}</Card.Text>
                        <Card.Text><strong>Price: </strong>${product.price}</Card.Text>
                        <Form.Group>
                            <Form.Label>Quantity</Form.Label>
                            <Form.Control
                                type="number"
                                min="1"
                                max={availableQuantity}
                                value={quantity}
                                onChange={handleQuantityChange}
                            />
                        </Form.Group>
                        {quantity > availableQuantity ? (
                            <Button variant="secondary" disabled>Out of Stock</Button>
                        ) : (
                            <Button onClick={handleAddToCart}>Add to Cart</Button>
                        )}
                    </Card.Body>
                </Card>
            )}
        </div>
        <Footer />
        </div>
    );
};

export default SingleProductPage;
