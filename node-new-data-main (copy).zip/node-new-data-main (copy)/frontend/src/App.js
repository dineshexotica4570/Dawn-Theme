import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Register from './components/Register';
import Login from './components/Login';
import Home from './components/home';
import Dashboard from './components/Dashboard';
import ListingPosts from './components/ListingPosts';
import ListingProducts from './components/ListingProducts';
import SinglePost from './components/SinglePost';
import Posts from './components/admin/Posts';
import Products from './components/admin/Products';
import ProtectedRoute from './components/ProtectedRoute';
import MainLayout from './components/admin/MainLayout';

import SingleProductPage from './components/SingleProductPage';
import CartPage from './components/CartPage';
import CheckoutPage from './components/CheckoutPage';

const App = () => {
    return (
        <Router>
            <Routes>
                <Route path="/register" element={<Register />} />
                <Route path="/login" element={<Login />} />
                <Route path="/posts" element={<ListingPosts />} />
                <Route path="/shop" element={<ListingProducts />} />

                <Route path="/products/singleproduct/:id" element={<SingleProductPage/>} />
                <Route path="/cart" element={<CartPage/>} />
                <Route path="/checkout" element={<CheckoutPage/>} />

                <Route path="/posts/singlepost/:id" element={<SinglePost />} />
                <Route path="/" element={<Home />} />

                <Route path="/" element={<ProtectedRoute element={MainLayout} />}>
                    <Route path="/dashboard" element={<Dashboard />} />
                    <Route path="/dashboard/posts" element={<Posts />} />
                    <Route path="/dashboard/products" element={<Products />} />
                    {/* Add more nested routes here */}
                </Route>
            </Routes>
        </Router>
    );
};

export default App;
