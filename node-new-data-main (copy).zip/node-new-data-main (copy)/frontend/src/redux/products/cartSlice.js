import { createSlice } from '@reduxjs/toolkit';

const cartSlice = createSlice({
    name: 'cart',
    initialState: { items: [] }, // Ensure items array is initialized
    reducers: {
        addItemToCart(state, action) {
            const item = action.payload;
            const existingItem = state.items.find((i) => i._id == item._id);
            if (existingItem) {
                existingItem.quantity += item.quantity;
            } else {
                state.items.push(item);
            }
        },
        updateItemQuantity(state, action) {
            const { id, quantity } = action.payload;
            const itemToUpdate = state.items.find((item) => item._id == id);
            if (itemToUpdate) {
                itemToUpdate.quantity = quantity;
            }
        },
        removeItemFromCart(state, action) {
            state.items = state.items.filter((item) => item._id !== action.payload);
        },
        clearCart(state) {
            state.items = [];
        },
    },
});

export const { addItemToCart, updateItemQuantity, removeItemFromCart, clearCart } = cartSlice.actions;
export default cartSlice.reducer;
